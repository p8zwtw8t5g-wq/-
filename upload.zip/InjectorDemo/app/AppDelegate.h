#import <UIKit/UIKit.h>

@interface RootVC : UIViewController
@property (strong, nonatomic) UILabel* status;
@end

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow* window;
@end
