#import "AppDelegate.h"
#import "Overlay.h"
#import "Config.h"
#import "Aim.h"
#import "KRW.h"
#import "SigScan.h"
#import "AutoScan.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

// cross-process host: attach to the game, then pump buildFrame/aimFrame at
// display rate. the overlay UI lives in our own window (run in Slide Over
// floating above the game).

static UILabel* g_status = nil;

@interface Host : NSObject
- (void)tick;
@end
@implementation Host
- (void)tick {
    static BOOL busy = NO;
    if (busy) return; busy = YES;
    @try {
        static int spin = 0; ++spin;
        bool ok = krwAttach();
        static bool scanned = false;
        if (ok) {
            if (!scanned) {
                scanned = true;
                sigScanAll(Config::sigs);
            }
            if (spin % 30 == 0)
                g_status.text = [NSString stringWithFormat:@"pid %d  base %llx  GWorld %llx",
                                 g_gamePid, (unsigned long long)g_gameBase,
                                 (unsigned long long)SIG.gworld];
            syncOffsets();
            buildFrame();
            aimFrame();
        } else if (spin % 60 == 0) {
            g_status.text = @"open the game (Valorant), it will connect automatically";
        }
        [(UIView*)g_rootCanvas() setNeedsDisplay];
    } @catch (...) {}
    busy = NO;
}
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)options {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.01];

    startOverlay(self.window);

    CGRect sc = UIScreen.mainScreen.bounds;
    g_status = [[UILabel alloc] initWithFrame:CGRectMake(8, sc.size.height - 26, sc.size.width - 16, 18)];
    g_status.text = @"looking for the game process...";
    g_status.textColor = [UIColor.systemGreenColor colorWithAlphaComponent:0.8];
    g_status.font = [UIFont systemFontOfSize:10];
    g_status.userInteractionEnabled = NO;
    [self.window addSubview:g_status];
    [self.window makeKeyAndVisible];

    Config::load();
    autoScanApplySaved();
    syncOffsets();
    extern NSString* g_skeletonPairs;
    g_skeletonPairs = @"";

    Host* h = [Host new];
    CADisplayLink* dl = [CADisplayLink displayLinkWithTarget:h selector:@selector(tick)];
    dl.preferredFramesPerSecond = 120;
    [dl addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];

    return YES;
}

@end
