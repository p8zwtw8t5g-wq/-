#import "AppDelegate.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)options {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = [[RootVC alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}

@end

@implementation RootVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithWhite:0.08 alpha:1];

    UILabel* title = [[UILabel alloc] initWithFrame:CGRectMake(20, 120, 280, 40)];
    title.text = @"Injector demo";
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont boldSystemFontOfSize:28];
    [self.view addSubview:title];

    self.status = [[UILabel alloc] initWithFrame:CGRectMake(20, 180, 340, 140)];
    self.status.textColor = [UIColor colorWithWhite:0.7 alpha:1];
    self.status.font = [UIFont systemFontOfSize:13];
    self.status.numberOfLines = 0;
    self.status.text = @"auto-launching game...\n\n- hold ball = aim / tap ball = menu\n- AutoScan = auto-fix offsets\n- config: /var/jb/share/InjectorDemo/config.plist";
    [self.view addSubview:self.status];

    UIButton* open = [UIButton buttonWithType:UIButtonTypeSystem];
    open.frame = CGRectMake(20, 340, 200, 44);
    open.backgroundColor = [UIColor.systemRedColor colorWithAlphaComponent:0.85];
    open.layer.cornerRadius = 10;
    [open setTitle:@"Re-launch Game" forState:UIControlStateNormal];
    [open setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [open addTarget:self action:@selector(openGame) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:open];

    // auto-jump into the game shortly after the icon is tapped
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ [self openGame]; });
}

- (void)openGame {
    NSArray* schemes = @[@"valorantmobile://", @"tencent1037://", @"com.tencent.valorantmobile://"];
    for (NSString* s in schemes) {
        NSURL* u = [NSURL URLWithString:s];
        if ([[UIApplication sharedApplication] canOpenURL:u]) {
            [[UIApplication sharedApplication] openURL:u options:@{} completionHandler:nil];
            return;
        }
    }
    self.status.text = @"game URL scheme not registered - launch from springboard manually.";
}

@end
