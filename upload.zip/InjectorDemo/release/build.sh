#!/bin/bash
# 一键打包 (macOS / Linux + theos)。产出在 packages/*.deb
set -e
cd "$(dirname "$0")"

export THEOS="${THEOS:-$HOME/theos}"
if [ ! -d "$THEOS" ]; then
  echo "[*] 首次运行：安装 theos"
  git clone --recursive -q https://github.com/theos/theos.git "$THEOS"
  curl -sL https://github.com/theos/sdks/archive/refs/heads/master.zip -o /tmp/sdks.zip
  unzip -q -o /tmp/sdks.zip -d /tmp/sdks
  mkdir -p "$THEOS/sdks"
  cp -R /tmp/sdks/sdks-master/iphoneos* "$THEOS/sdks/" 2>/dev/null || true
fi

# dm.pl (make package 需要) 在裸 clone 里不在 PATH 上
if [ -f "$THEOS/vendor/dm.pl/dm.pl" ]; then
  chmod +x "$THEOS/vendor/dm.pl/dm.pl"
  export PATH="$THEOS/vendor/dm.pl:$PATH"
fi

chmod +x postinst
make package FINALPACKAGE=1 THEOS_PLATFORM_DEB_COMPRESSION_TYPE=gzip

echo ""
echo "[+] 完成，deb 内容如下："
DEB="$(pwd)/$(ls packages/*.deb | head -1)"
echo "    $DEB"
rm -rf /tmp/debx && mkdir -p /tmp/debx && cd /tmp/debx
ar x "$DEB"
for f in data.tar.*; do tar -tf "$f"; done
