#pragma once
#include "UE.h"

// humanized aim engine (top-spec):
//  - reaction delay (position history sampling, dist-scaled)
//  - spring-damped screen-space pull with per-weapon speed cap
//  - tracking inertia: lazy follow, whip-catch on target direction flips
//  - overshoot-correction: rolls a chance to pull past the target then
//    re-correct with a slightly different (more cautious) gain
//  - asymmetric brownian jitter (horizontal > vertical, like a thumb)
//  - micro-flicks: rare fast small corrections mid-aim
//  - lock-break micro-drift (never locks robotically)
//  - wall pre-aim: occluded target -> damped follow of velocity-extrapolated peek point
struct AimState {
    u64    targetId = 0;
    f32    lockTime = 0.f;     // seconds on same target
    f32    driftLeft = 0.f;    // active micro-drift duration
    f32    driftX = 0.f, driftY = 0.f;
    f32    jx = 0.f, jy = 0.f; // brownian state
    FVec   hist[128];
    f64    histT[128];
    int    histCount = 0;

    // tracking inertia
    f32    lagYaw = 0.f, lagPitch = 0.f;   // low-passed error (lazy follow)
    f32    prevYawErr = 0.f, prevPitchErr = 0.f;

    // overshoot-correction
    bool   ovActive = false;   // currently burning overshoot
    f32    ovYaw = 0.f, ovPitch = 0.f;     // remaining overshoot (deg)
    f32    correctLeft = 0.f;  // post-overshoot cautious re-pull timer

    // micro-flicks
    f32    flickLeft = 0.f;    // active flick duration
    f32    flickYaw = 0.f, flickPitch = 0.f;
};

void aimFrame();
bool w2sFrame(const struct Frame& f, const FVec& w, f32& sx, f32& sy);
struct WeaponProfile;
WeaponProfile* currentWeaponProfile();
