#import "Aim.h"
#import "Config.h"
#import "Overlay.h"
#import "TouchMon.h"
#import "SigScan.h"
#import "StrObf.h"
#import <Foundation/Foundation.h>
#import <mach/mach.h>

AimState g_aim;

// set each frame by the reader in Tweak.mm
uintptr_t g_localPC = 0;
void applyAimRotation(f32 dYaw, f32 dPitch);

static f32 randf() { return (f32)arc4random() / (f32)UINT32_MAX * 2.f - 1.f; }

static inline f32 dot3(const FVec& a, const FVec& b) { return a.x*b.x + a.y*b.y + a.z*b.z; }
static inline FVec sub3(const FVec& a, const FVec& b) { return {a.x-b.x, a.y-b.y, a.z-b.z}; }

// camera basis from rotation (UE convention: pitch around Y, yaw around Z, roll around X)
static void camAxes(const FRot& r, FVec& fwd, FVec& right, FVec& up) {
    const f32 d = 3.14159265f / 180.f;
    f32 sp = sinf(r.pitch*d), cp = cosf(r.pitch*d);
    f32 sy = sinf(r.yaw*d),   cy = cosf(r.yaw*d);
    f32 sr = sinf(r.roll*d),  cr = cosf(r.roll*d);
    fwd   = { cp*cy, cp*sy, sp };
    right = { sr*sp*cy - cr*sy, sr*sp*sy + cr*cy, -sr*cp };
    up    = { cr*sp*cy + sr*sy, cr*sp*sy - sr*cy, cr*cp };
}

bool w2sFrame(const Frame& f, const FVec& w, f32& sx, f32& sy) {
    FVec rel = sub3(w, f.camLoc);
    FVec fwd, right, up; camAxes(f.camRot, fwd, right, up);
    f32 z = dot3(rel, fwd);
    if (z < 1.f) return false;
    f32 x = dot3(rel, right);
    f32 y = dot3(rel, up);
    f32 tanH = tanf(f.fov * 0.5f * 3.14159265f/180.f);
    f32 tanV = tanH * (f32)f.screenH / (f32)f.screenW;
    sx = (f32)f.screenW * 0.5f * (1.f + x / (z * tanH));
    sy = (f32)f.screenH * 0.5f * (1.f - y / (z * tanV));
    return true;
}

// target head position, reaction-delayed (position history sampling)
static FVec sampledTarget(const Entity& e, f64 now) {
    f32 delayMs = Config::reactBaseMs + e.dist * Config::reactPerMeterMs;
    delayMs *= (0.85f + 0.3f * (f32)(arc4random() % 1000) / 1000.f); // +-15%
    f64 want = now - (f64)delayMs / 1000.0;

    AimState& a = g_aim;
    if (a.targetId != e.id) { a.histCount = 0; a.targetId = e.id; a.lockTime = 0.f; }
    if (a.histCount < 128) { a.hist[a.histCount] = e.head; a.histT[a.histCount] = now; a.histCount++; }
    else { for (int i = 1; i < 128; ++i) { a.hist[i-1] = a.hist[i]; a.histT[i-1] = a.histT[i]; }
           a.hist[127] = e.head; a.histT[127] = now; }

    for (int i = a.histCount - 1; i >= 0; --i)
        if (a.histT[i] <= want) return a.hist[i];
    return e.head;
}

// wall pre-aim: extrapolate along velocity so the crosshair pre-holds the peek line
static FVec predictPeek(const Entity& e, f32 leadMs) {
    f32 t = leadMs / 1000.f;
    return { e.head.x + e.vel.x*t, e.head.y + e.vel.y*t, e.head.z + e.vel.z*t };
}

void aimFrame() {
    Frame& f = g_frame;
    if (!f.ready || !g_localPC || !g_sw.master || !g_sw.aim || g_sw.safeMode) return;
    if (f.localDead) return;
    if (!g_aimTrigger) { g_aim.targetId = 0; return; } // trigger not held -> hands off

    WeaponProfile* wp = currentWeaponProfile();
    f32 fovR = wp->fov * Config::fovGlobalMul * g_sw.fovMul;

    // pick best target: nearest to crosshair inside fov, visible preferred
    Entity* best = nullptr; f32 bestScore = 1e30f;
    for (int i = 0; i < f.entCount; ++i) {
        Entity& e = f.ents[i];
        if (!e.used || !e.alive || e.pawn == f.localPawn) continue;
        if (f.localTeam >= 0 && e.team == f.localTeam && e.team != 0) continue;
        f32 sx, sy;
        if (!w2sFrame(f, e.head, sx, sy)) continue;
        f32 dx = sx - f.screenW*0.5f, dy = sy - f.screenH*0.5f;
        f32 d2 = dx*dx + dy*dy;
        if (d2 > fovR*fovR) continue;
        if (!e.visible) d2 *= 1.6f; // prefer visible targets
        if (d2 < bestScore) { bestScore = d2; best = &e; }
    }
    if (!best) { g_aim.targetId = 0; return; }

    Entity& e = *best;
    int lock = (g_sw.lockPart >= 0) ? g_sw.lockPart : wp->lock;
    FVec aimWorld = e.head;
    if (e.boneOk) {
        if (lock == 0)      aimWorld = e.head;
        else if (lock == 1) aimWorld = e.bones[e.boneCount > 66 ? 66 : 2]; // neck
        else                aimWorld = e.bones[e.boneCount > 6  ? 6  : 2]; // chest/spine_03
    }

    AimState& a = g_aim;
    bool newTarget = (a.targetId != e.id);
    if (newTarget) { a.lockTime = 0.f; a.targetId = e.id;
                     a.lagYaw = 0.f; a.lagPitch = 0.f;
                     a.ovActive = false; a.ovYaw = 0.f; a.ovPitch = 0.f;
                     a.correctLeft = 0.f; a.flickLeft = 0.f; }
    a.lockTime += 1.f / 120.f;

    FVec goal;
    if (!e.visible) goal = predictPeek(e, wp->leadMs);
    else            goal = sampledTarget(e, f.now);

    f32 sx, sy;
    if (!w2sFrame(f, goal, sx, sy)) return;

    // angular error toward goal
    FVec rel = sub3(goal, f.camLoc);
    FVec fwd, right, up; camAxes(f.camRot, fwd, right, up);
    f32 yawErr   = atan2f(dot3(rel, right), dot3(rel, fwd));
    f32 pitchErr = -atan2f(dot3(rel, up), dot3(rel, fwd));

    // ---- tracking inertia: lazy follow, whip-catch on flips/growth ----
    // humans track with inertia: slow to start, then snap when they realize
    // the target broke away. alpha = low-pass factor on the error.
    bool flipped  = (yawErr * a.prevYawErr < 0.f) || (pitchErr * a.prevPitchErr < 0.f);
    bool grewFast = (fabsf(yawErr)   > fabsf(a.prevYawErr)   * 1.5f + 0.4f) ||
                    (fabsf(pitchErr) > fabsf(a.prevPitchErr) * 1.5f + 0.4f);
    f32 alpha = (flipped || grewFast) ? Config::inertiaCatch : Config::inertiaLag;
    if (a.lagYaw == 0.f && a.lagPitch == 0.f) { a.lagYaw = yawErr; a.lagPitch = pitchErr; }
    a.lagYaw   = a.lagYaw   * (1.f - alpha) + yawErr   * alpha;
    a.lagPitch = a.lagPitch * (1.f - alpha) + pitchErr * alpha;
    a.prevYawErr = yawErr; a.prevPitchErr = pitchErr;

    // ---- overshoot-correction: pull past, then re-correct cautiously ----
    // on acquisition (or big re-acquire), humans often overshoot by 1-3 deg
    // then correct back with a slightly softer hand. roll for it once.
    if (newTarget && fabsf(yawErr) > 3.5f &&
        (f32)(arc4random() % 1000) / 1000.f < Config::overshootChance) {
        f32 mag = (1.f + 2.f * (f32)((arc4random() % 1000) / 1000.f))   // 1..3 deg
                  * fminf(fabsf(yawErr) / 8.f, 1.f);                    // scale w/ error
        a.ovYaw   = (yawErr   > 0.f ? mag : -mag);
        a.ovPitch = (pitchErr > 0.f ? mag : -mag) * 0.4f;               // thumbs overshoot more horizontally
        a.ovActive = true;
    }
    f32 ovContrY = 0.f, ovContrP = 0.f;
    if (a.ovActive) {
        // burn exponentially (tau ~ overshootTauMs); add remainder as bias
        f32 decay = expf(-(1.f / 120.f) * 1000.f / Config::overshootTauMs);
        ovContrY = a.ovYaw; ovContrP = a.ovPitch;
        a.ovYaw *= decay; a.ovPitch *= decay;
        if (fabsf(a.ovYaw) < 0.05f && fabsf(a.ovPitch) < 0.05f) {
            a.ovActive = false;
            a.correctLeft = 0.15f;   // cautious re-pull window
        }
    }
    f32 correctMul = (a.correctLeft > 0.f) ? 0.85f : 1.f;
    if (a.correctLeft > 0.f) a.correctLeft -= 1.f / 120.f;

    // ---- micro-flicks: rare fast small stick corrections mid-aim ----
    if (a.flickLeft <= 0.f &&
        (f32)(arc4random() % 10000) / 10000.f < Config::flickChance) {
        a.flickYaw   = randf() * 0.8f;
        a.flickPitch = randf() * 0.5f;
        a.flickLeft  = 0.05f + 0.04f * (f32)((arc4random() % 1000) / 1000.f);
    }
    f32 flY = 0.f, flP = 0.f;
    if (a.flickLeft > 0.f) {
        a.flickLeft -= 1.f / 120.f;
        flY = a.flickYaw; flP = a.flickPitch;
    }

    f32 gain = 1.f / wp->smooth;
    if (!e.visible) gain *= Config::leadVisDamp; // soft follow while pre-aiming

    // lock-break micro-drift: after lockBreakSec on one target, humanize off/on
    if (a.lockTime > Config::lockBreakSec && a.driftLeft <= 0.f)
        a.driftLeft = 0.12f + 0.13f * (f32)((arc4random() % 1000) / 1000.f);
    f32 driftMul = 1.f, dx0 = 0.f, dy0 = 0.f;
    if (a.driftLeft > 0.f) {
        a.driftLeft -= 1.f/120.f;
        driftMul = 0.1f;
        dx0 = randf()*0.5f; dy0 = randf()*0.35f;
    }

    // asymmetric brownian hand jitter: thumb is worse horizontally
    a.jx = a.jx * 0.92f + randf() * Config::jitterAmp * 0.08f;
    a.jy = a.jy * 0.92f + randf() * Config::jitterAmp * 0.08f * Config::jitterVertMul;

    f32 stepYaw   = (a.lagYaw * gain + ovContrY + flY + dx0 + a.jx) * driftMul * correctMul;
    f32 stepPitch = (a.lagPitch * gain + ovContrP + flP + dy0 + a.jy) * driftMul * correctMul;
    f32 cap = wp->speed * (e.visible ? 1.f : 0.7f);
    if (stepYaw   >  cap) stepYaw   =  cap; if (stepYaw   < -cap) stepYaw   = -cap;
    if (stepPitch >  cap) stepPitch =  cap; if (stepPitch < -cap) stepPitch = -cap;

    // touch-drive: feed game-native input pipeline (sensitivity applies);
    // rotation mode: direct ControlRotation write
    extern bool g_tdReady;
    extern void touchDriveFeed(f32, f32);
    if (Config::aimTouch && g_tdReady)
        touchDriveFeed(stepYaw * Config::touchGain, stepPitch * Config::touchGain);
    else
        applyAimRotation(stepYaw, stepPitch);
}
