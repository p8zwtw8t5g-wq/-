#pragma once
#import <Foundation/Foundation.h>

// heuristic offset auto-discovery: finds live objects by class-name chain,
// pattern-scans their memory for struct members, validates, applies, saves.
void autoScanStart(void);          // async run (safe to call from UI)
void autoScanApplySaved(void);     // on boot: apply previous scan results
bool autoScanBusy(void);
bool autoScanLastOK(void);
NSString* autoScanStatusText(void);
