#import "AutoScan.h"
#import "Config.h"
#import "Overlay.h"
#import "SigScan.h"
#import "KRW.h"
#import "StrObf.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <mach/mach.h>
#import <stdio.h>
#import <math.h>

static NSString* docPath(NSString* fn) { return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:fn]; }

// ------------------------------------------------------------------ state

static bool g_busy = false;
static bool g_lastOK = false;
static NSMutableString* g_status = nil;

bool autoScanBusy()     { return g_busy; }
bool autoScanLastOK()   { return g_lastOK; }
NSString* autoScanStatusText() { return g_status ?: @"AutoScan: idle"; }

// ------------------------------------------------------------------ safe memory access

static bool safeRd(u64 a, void* out, u64 sz) {
    if (!a || a < 0x10000 || a > 0x800000000000ULL) return false;
    return rd(a, out, sz); // KRW remote read (mach_vm under the hood)
}
static u64 sPtr(u64 a) { u64 v = 0; return safeRd(a, &v, 8) ? v : 0; }
static f32 sF32(u64 a) { f32 v = NAN;    safeRd(a, &v, 4); return v; }
static i32 sI32(u64 a) { i32 v = 0;      safeRd(a, &v, 4); return v; }
static bool plausiblePtr(u64 p) { return p > 0x100000 && p < 0x800000000000ULL; }
static bool fin(f32 f) { return f == f && fabsf(f) < 1e10f; }

// ------------------------------------------------------------------ names & classes

NSString* fNameToString(i32 index); // implemented in Tweak.mm

static u32 ObjectNameOff = 0x18;   // UObject::NamePrivate
static u32 ClassPrivOff  = 0x10;   // UObject::ClassPrivate
static u32 SuperStructOff = 0x40;  // UStruct::SuperStruct

static NSString* objName(u64 o) {
    if (!o) return nil;
    i32 idx = sI32(o + ObjectNameOff);
    return fNameToString(idx);
}

// true if obj's class chain (ClassPrivate -> SuperStruct -> ...) contains keyword
static bool classChainMatch(u64 obj, NSString* keyword) {
    u64 cls = sPtr(obj + ClassPrivOff);
    for (int depth = 0; cls && depth < 10; ++depth) {
        NSString* n = objName(cls);
        if (n && [n rangeOfString:keyword options:NSCaseInsensitiveSearch].location != NSNotFound) return true;
        u64 super = sPtr(cls + SuperStructOff);
        if (super == cls) break;
        cls = super;
    }
    return false;
}

// ------------------------------------------------------------------ object array walk (UE4.23+ chunked)

static NSMutableArray* collectInstances(NSArray* keywords, int cap) {
    NSMutableArray* out = [NSMutableArray array];
    if (!SIG.guobject) return out;
    u64 chunksBase = sPtr(SIG.guobject);
    i32 numElems   = sI32(SIG.guobject + 0xC);
    i32 numChunks  = sI32(SIG.guobject + 0x14);
    if (!chunksBase || numElems <= 0 || numElems > 500000) return out;
    const i32 perChunk = 65536;

    for (i32 c = 0; c < numChunks && c < 128 && (int)out.count < cap; ++c) {
        u64 chunk = sPtr(chunksBase + (u64)c * 8);
        if (!chunk) continue;
        i32 last = MIN(perChunk, numElems - c * perChunk);
        for (i32 j = 0; j < last && (int)out.count < cap; ++j) {
            u64 o = sPtr(chunk + (u64)j * 8);
            if (!plausiblePtr(o)) continue;
            for (NSString* kw in keywords)
                if (classChainMatch(o, kw)) { [out addObject:@(o)]; break; }
        }
    }
    return out;
}

// ------------------------------------------------------------------ generic member probes

// find offset in [from,to) where a pointer field points to object matching keyword
static u32 scanPtrToObject(u64 host, u32 from, u32 to, NSArray* keywords) {
    for (u32 off = from & ~7; off + 8 <= to; off += 8) {
        u64 p = sPtr(host + off);
        if (!plausiblePtr(p)) continue;
        for (NSString* kw in keywords)
            if (classChainMatch(p, kw)) return off;
    }
    return 0;
}

// find offset where ptr+0 = valid ptr, ptr+8 = int in [lo,hi] (TArray with count)
static u32 scanArrayField(u64 host, u32 from, u32 to, int lo, int hi,
                          bool (^elemCheck)(u64)) {
    for (u32 off = from & ~7; off + 16 <= to; off += 8) {
        u64 p = sPtr(host + off);
        if (!plausiblePtr(p)) continue;
        i32 n = sI32(host + off + 8);
        if (n < lo || n > hi) continue;
        if (elemCheck && !elemCheck(sPtr(p))) continue;
        return off;
    }
    return 0;
}

// ------------------------------------------------------------------ scan engine

static Offsets WORK;   // candidate offsets
static void logf(NSString* fmt, ...) NS_FORMAT_FUNCTION(1,2);
static void logf(NSString* fmt, ...) {
    va_list ap; va_start(ap, fmt);
    [g_status appendFormat:@"%@\n", [[NSString alloc] initWithFormat:fmt arguments:ap]];
    va_end(ap);
}

static void applyOff(NSString* key, u32 val, u32* target, NSMutableDictionary* saved) {
    bool manual = [Config::explicitKeys containsObject:key];
    if (val && !manual) {
        *target = val;
        [saved setObject:@(val) forKey:key];
        logf(@"  %@ -> 0x%X", key, val);
    } else if (val && manual) {
        logf(@"  %@ found 0x%X but manual config wins (0x%X)", key, val, *target);
    } else {
        logf(@"  %@ not found, keep 0x%X", key, *target);
    }
}

static bool quatNormalized(u64 a) {
    f32 q[4]; if (!safeRd(a, q, 16)) return false;
    f32 n = q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+q[3]*q[3];
    return fin(n) && fabsf(n - 1.f) < 0.02f;
}

static void runAutoScan() {
    g_busy = true; g_lastOK = false;
    g_status = [NSMutableString stringWithString:@"AutoScan:\n"];
    WORK = Config::off; // start from current values, overwrite what we find

    // 0. object array sanity
    u64 probe = sPtr(SIG.guobject);
    if (!probe) { logf(@"GUObject sig missing - scan aborted"); g_busy = false; return; }

    // 1. GameInstance -> LocalPlayers -> LocalPlayer
    u64 gameInstAddr = [(NSNumber*)[collectInstances(@[@"GameInstance"], 8) firstObject] longLongValue];
    if (!gameInstAddr) { logf(@"no GameInstance"); g_busy = false; return; }
    u32 lpOff = 0;
    for (u32 off = 0x20; off + 16 <= 0x200; off += 8) {
        u64 arr = sPtr(gameInstAddr + off);
        u64 lp0 = arr ? sPtr(arr) : 0;
        if (lp0 && classChainMatch(lp0, @"LocalPlayer")) { lpOff = off; break; }
    }
    logf(@"LocalPlayers 0x%X", lpOff);
    u64 lp = lpOff ? sPtr(sPtr(gameInstAddr + lpOff)) : 0;

    // 2. LocalPlayer -> PlayerController
    u32 pcOff = lp ? scanPtrToObject(lp, 0x20, 0x200, @[@"PlayerController"]) : 0;
    logf(@"PlayerController 0x%X", pcOff);
    u64 pc = pcOff ? sPtr(lp + pcOff) : 0;

    // 3. PC -> Pawn (chain "Pawn" matches Character subclasses too)
    u32 pawnOff = pc ? scanPtrToObject(pc, 0x20, 0x400, @[@"Pawn"]) : 0;
    logf(@"Pawn 0x%X", pawnOff);
    u64 localPawn = pawnOff ? sPtr(pc + pawnOff) : 0;

    // 4. PC -> PlayerCameraManager
    u32 camOff = pc ? scanPtrToObject(pc, 0x20, 0x400, @[@"PlayerCameraManager"]) : 0;
    logf(@"CameraManager 0x%X", camOff);
    u64 camMgr = camOff ? sPtr(pc + camOff) : 0;

    // 5. CameraCache: find FMinimalViewInfo pattern {loc, rot, fov}
    u32 povOff = 0;
    if (camMgr) {
        for (u32 off = 0x100; off + 0x20 <= 0x2000; off += 4) {
            u64 a = camMgr + off;
            f32 fov = sF32(a + 0x18);
            f32 pit = sF32(a + 0x0C), yaw = sF32(a + 0x10);
            if (fov > 60.f && fov < 130.f && fin(fov) &&
                fabsf(pit) <= 90.5f && fabsf(yaw) <= 180.5f &&
                fin(sF32(a)) && fin(sF32(a + 4)) && fin(sF32(a + 8))) {
                povOff = off; break;
            }
        }
    }
    logf(@"CameraCache 0x%X (POV-0x10)", povOff ? povOff - 0x10 : 0);

    // 6. ControlRotation: 3 floats near current cam rot, two-frame validated
    u32 ctrlOff = 0;
    if (pc && povOff) {
        f32 refP = sF32(camMgr + povOff + 0x0C), refY = sF32(camMgr + povOff + 0x10);
        for (u32 off = 0x100; off + 12 <= 0x800; off += 4) {
            u64 a = pc + off;
            f32 p = sF32(a), y = sF32(a + 4), r = sF32(a + 8);
            if (!fin(p) || !fin(y) || !fin(r)) continue;
            if (fabsf(p) > 90.5f || fabsf(y) > 180.5f) continue;
            if (fabsf(p - refP) < 3.f && fabsf(y - refY) < 3.f) {
                // still matches after a beat -> live rotation, not a cache
                [NSThread sleepForTimeInterval:0.08];
                f32 p2 = sF32(camMgr + povOff + 0x0C), y2 = sF32(camMgr + povOff + 0x10);
                f32 p3 = sF32(a), y3 = sF32(a + 4);
                if (fabsf(p3 - p2) < 3.f && fabsf(y3 - y2) < 3.f) { ctrlOff = off; break; }
            }
        }
    }
    logf(@"ControlRotation 0x%X", ctrlOff);

    // 7. World -> GameState
    u64 world = sPtr(SIG.gworld);
    u32 gsOff = world ? scanPtrToObject(world, 0x20, 0x400, @[@"GameState"]) : 0;
    logf(@"GameState 0x%X", gsOff);
    u64 gs = gsOff ? sPtr(world + gsOff) : 0;

    // 8. GameState -> PlayerArray (elems are PlayerState)
    u32 paOff = 0;
    if (gs) {
        for (u32 off = 0x20; off + 16 <= 0x800; off += 8) {
            u64 arr = sPtr(gs + off);
            i32 n = sI32(gs + off + 8);
            u64 e0 = (arr && n > 0 && n <= 64) ? sPtr(arr) : 0;
            if (e0 && classChainMatch(e0, @"PlayerState")) { paOff = off; break; }
        }
    }
    logf(@"PlayerArray 0x%X", paOff);

    // 9. PlayerState -> PawnPrivate (points to any live pawn)
    NSMutableArray* pawnInstances = collectInstances(@[@"Pawn"], 32);
    u32 ppOff = 0;
    if (paOff && gs && pawnInstances.count) {
        u64 arr = sPtr(gs + paOff);
        i32 n = sI32(gs + paOff + 8);
        u64 ps0 = n > 0 ? sPtr(arr) : 0;
        if (ps0) {
            for (u32 off = 0x20; off + 8 <= 0x800; off += 8) {
                u64 p = sPtr(ps0 + off);
                for (NSNumber* pn in pawnInstances)
                    if ((u64)pn.longLongValue == p) { ppOff = off; break; }
                if (ppOff) break;
            }
        }
    }
    logf(@"PawnPrivate 0x%X", ppOff);

    // 10. Character -> Mesh (skeletal mesh component)
    u32 meshOff = 0;
    for (NSNumber* pn in pawnInstances) {
        u64 p = (u64)pn.longLongValue;
        u32 o = scanPtrToObject(p, 0x20, 0x600, @[@"SkeletalMesh", @"SkinnedMesh"]);
        if (o) { meshOff = o; break; }
    }
    logf(@"Mesh 0x%X", meshOff);

    // 11. MeshComp -> ComponentToWorld (normalized quat @ off, plausible pos after)
    u32 c2wOff = 0;
    u64 meshComp = (localPawn && meshOff) ? sPtr(localPawn + meshOff) : 0;
    if (meshComp) {
        for (u32 off = 0x100; off + 48 <= 0x300; off += 4) {
            u64 a = meshComp + off;
            if (quatNormalized(a)) {
                f32 px = sF32(a + 16), py = sF32(a + 20), pz = sF32(a + 24);
                if (fin(px) && fin(py) && fin(pz)) { c2wOff = off; break; }
            }
        }
    }
    logf(@"ComponentToWorld 0x%X", c2wOff);

    // 12. MeshComp -> BoneArray (ptr + count 40..128, first quat normalized)
    u32 baOff = 0, bcOff = 0;
    if (meshComp) {
        for (u32 off = 0x100; off + 16 <= 0x800; off += 8) {
            u64 p = sPtr(meshComp + off);
            if (!plausiblePtr(p)) continue;
            i32 n = sI32(meshComp + off + 8);
            if (n < 40 || n > 128) continue;
            if (quatNormalized(p)) { baOff = off; bcOff = off + 8; break; }
        }
    }
    logf(@"BoneArray 0x%X / Num 0x%X", baOff, bcOff);

    // 13. Character -> Weapon (class chain keyword)
    u32 wpnOff = localPawn ? scanPtrToObject(localPawn, 0x20, 0xC00,
                       @[@"Weapon", @"Gun", @"Equipable"]) : 0;
    logf(@"Weapon 0x%X", wpnOff);

    // 14. TeamOffset: int in [0,31] shared by some PS, differing on others
    u32 teamOff = 0;
    if (paOff && gs) {
        u64 arr = sPtr(gs + paOff);
        i32 n = sI32(gs + paOff + 8);
        if (arr && n >= 3) {
            u64 psA = sPtr(arr);
            for (u32 off = 0x20; off + 4 <= 0x800 && !teamOff; off += 4) {
                i32 va = sI32(psA + off);
                if (va < 0 || va > 31) continue;
                int same = 0, diff = 0;
                for (int k = 1; k < n && k < 32; ++k) {
                    u64 ps = sPtr(arr + (u64)k * 8);
                    if (!ps) continue;
                    i32 vb = sI32(ps + off);
                    if (vb == va) same++; else if (vb >= 0 && vb <= 31) diff++;
                }
                if (same >= 1 && diff >= 1) teamOff = off;
            }
        }
    }
    logf(@"TeamOffset 0x%X", teamOff);

    // ---------------- apply + save (manual config wins) ----------------
    NSMutableDictionary* saved = [NSMutableDictionary dictionary];
    Offsets& o = Config::off;
    applyOff(@"GameInstance",        lpOff,   &o.GameInstance,        saved);
    applyOff(@"LocalPlayers",        lpOff,   &o.LocalPlayers,        saved);
    applyOff(@"PlayerController",    pcOff,   &o.PlayerController,    saved);
    applyOff(@"Pawn",                pawnOff, &o.Pawn,                saved);
    applyOff(@"PlayerCameraManager", camOff,  &o.PlayerCameraManager, saved);
    applyOff(@"CameraCache",         povOff ? povOff - 0x10 : 0, &o.CameraCache, saved);
    applyOff(@"ControlRotation",     ctrlOff, &o.ControlRotation,     saved);
    applyOff(@"GameState",           gsOff,   &o.GameState,           saved);
    applyOff(@"PlayerArray",         paOff,   &o.PlayerArray,         saved);
    applyOff(@"PawnPrivate",         ppOff,   &o.PawnPrivate,         saved);
    applyOff(@"Mesh",                meshOff, &o.Mesh,                saved);
    applyOff(@"ComponentToWorld",    c2wOff,  &o.ComponentToWorld,    saved);
    applyOff(@"BoneArray",           baOff,   &o.BoneArray,           saved);
    applyOff(@"BoneArray+Num",       bcOff,   &o.BoneCount,           saved);
    applyOff(@"Weapon",              wpnOff,  &o.Weapon,              saved);
    applyOff(@"TeamOffset",          teamOff, &o.TeamOffset,          saved);

    [saved writeToFile:docPath(@"config.autoscan.plist") atomically:YES];
    [g_status writeToFile:docPath(@"autoscan.txt") atomically:YES
               encoding:NSUTF8StringEncoding error:nil];

    g_lastOK = (pcOff && camOff && gsOff && paOff && meshOff && baOff);
    logf(g_lastOK ? @"\nOK - applied." : @"\nPartial - some offsets kept old values.");
    g_busy = false;
}

// ------------------------------------------------------------------ public

void autoScanApplySaved() {
    NSDictionary* saved = [NSDictionary dictionaryWithContentsOfFile:
                           docPath(@"config.autoscan.plist")];
    if (!saved.count) return;
    Offsets& o = Config::off;
    o.GameInstance        = [saved[@"GameInstance"]      unsignedIntValue] ?: o.GameInstance;
    o.LocalPlayers        = [saved[@"LocalPlayers"]      unsignedIntValue] ?: o.LocalPlayers;
    o.PlayerController    = [saved[@"PlayerController"]  unsignedIntValue] ?: o.PlayerController;
    o.Pawn                = [saved[@"Pawn"]              unsignedIntValue] ?: o.Pawn;
    o.PlayerCameraManager = [saved[@"PlayerCameraManager"] unsignedIntValue] ?: o.PlayerCameraManager;
    o.CameraCache         = [saved[@"CameraCache"]       unsignedIntValue] ?: o.CameraCache;
    o.ControlRotation     = [saved[@"ControlRotation"]   unsignedIntValue] ?: o.ControlRotation;
    o.GameState           = [saved[@"GameState"]         unsignedIntValue] ?: o.GameState;
    o.PlayerArray         = [saved[@"PlayerArray"]       unsignedIntValue] ?: o.PlayerArray;
    o.PawnPrivate         = [saved[@"PawnPrivate"]       unsignedIntValue] ?: o.PawnPrivate;
    o.Mesh                = [saved[@"Mesh"]              unsignedIntValue] ?: o.Mesh;
    o.ComponentToWorld    = [saved[@"ComponentToWorld"]  unsignedIntValue] ?: o.ComponentToWorld;
    o.BoneArray           = [saved[@"BoneArray"]         unsignedIntValue] ?: o.BoneArray;
    o.BoneCount           = [saved[@"BoneArray+Num"]     unsignedIntValue] ?: o.BoneCount;
    o.Weapon              = [saved[@"Weapon"]            unsignedIntValue] ?: o.Weapon;
    o.TeamOffset          = [saved[@"TeamOffset"]        unsignedIntValue] ?: o.TeamOffset;
}

static void autoScanKick() {
    extern Offsets OFF; // Tweak.mm
    if (g_busy) return;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        runAutoScan();
        OFF = Config::off; // push results into the hot chain
    });
}

void autoScanStart() { autoScanKick(); }
