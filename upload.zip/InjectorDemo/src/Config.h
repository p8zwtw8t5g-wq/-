#pragma once
#import <Foundation/Foundation.h>
#include "UE.h"

struct WeaponProfile {
    NSString* name;   // matched as substring against current weapon object name
    float fov;        // screen-space lock radius (px at 1x scale)
    float smooth;     // >1 = softer
    int   lock;       // 0 head, 1 neck, 2 chest
    float speed;      // max deg per frame
    float leadMs;     // wall pre-aim extrapolation time
};

class Config {
public:
    static void load();

    static Offsets off;
    static NSDictionary* sigs;      // GWorld/GNames/GUObject/DecKey patterns
    static NSMutableArray<WeaponProfile*>* weapons;
    static WeaponProfile def;
    static NSMutableArray<NSString*>* explicitKeys; // keys set manually in config.plist (autoscan won't override)

    static int  decryptMode;        // 0 plain, 1 rolling XOR key, 2 48-bit packed
    static u32  nameXorKey;
    static float reactBaseMs;       // human reaction floor
    static float reactPerMeterMs;   // + per meter distance
    static float jitterAmp;         // deg
    static float jitterVertMul;     // vertical jitter = jitterAmp * this (thumb is worse horizontally)
    static float lockBreakSec;      // continuous lock then micro-drift
    static float leadVisDamp;       // gain multiplier while pre-aiming through wall
    static float inertiaLag;        // tracking inertia: low-pass alpha in steady follow (lazy)
    static float inertiaCatch;      // tracking inertia: alpha on flip/fast growth (whip-catch)
    static float overshootChance;   // chance to overshoot on target acquisition
    static float overshootTauMs;    // overshoot burn decay time constant
    static float flickChance;       // per-frame chance of a micro-flick correction
    static float fovGlobalMul;
    static bool  aimTouch;          // true = drive aim via AddYaw/PitchInput (game-native), false = write ControlRotation
    static float touchGain;         // input gain in touch mode
    static float radarRange;        // radar minimap range in meters

    static WeaponProfile* match(NSString* weaponName);
};
