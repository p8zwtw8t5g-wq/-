#import "Config.h"
#import "StrObf.h"

Offsets Config::off;
NSDictionary* Config::sigs = nil;
NSMutableArray* Config::weapons = nil;
NSMutableArray<NSString*>* Config::explicitKeys = nil;
WeaponProfile Config::def = { nil, 26.f, 1.6f, 1, 2.6f, 0.f };

int   Config::decryptMode  = 0;
u32   Config::nameXorKey   = 0;
float Config::reactBaseMs  = 90.f;
float Config::reactPerMeterMs = 5.f;
float Config::jitterAmp    = 0.12f;
float Config::jitterVertMul = 0.55f;
float Config::lockBreakSec = 3.5f;
float Config::leadVisDamp  = 0.45f;
float Config::inertiaLag   = 0.22f;
float Config::inertiaCatch = 0.75f;
float Config::overshootChance = 0.30f;
float Config::overshootTauMs  = 110.f;
float Config::flickChance  = 0.0015f;
float Config::fovGlobalMul = 1.f;
bool  Config::aimTouch     = true;
float Config::touchGain    = 0.9f;
float Config::radarRange   = 40.f;

static u32 num(NSDictionary* d, NSString* k, u32 fallback) {
    id v = d[k];
    return v ? (u32)[v unsignedIntValue] : fallback;
}
static f32 flt(NSDictionary* d, NSString* k, f32 fallback) {
    id v = d[k];
    return v ? (f32)[v doubleValue] : fallback;
}
static u32 numK(NSDictionary* d, const char* key, u32 fallback) {
    return num(d, @(key), fallback);
}
static f32 fltK(NSDictionary* d, const char* key, f32 fallback) {
    return flt(d, @(key), fallback);
}

static void loadOffsets(NSDictionary* d) {
    Offsets& o = Config::off;
    if (!Config::explicitKeys) Config::explicitKeys = [NSMutableArray new];
    struct { NSString* key; u32* target; u32 fallback; } map[] = {
        { @"GameState",           &o.GameState,           0x140 },
        { @"GameInstance",        &o.GameInstance,        0x1B0 },
        { @"LocalPlayers",        &o.LocalPlayers,        0x38  },
        { @"PlayerController",    &o.PlayerController,    0x30  },
        { @"Pawn",                &o.Pawn,                0x2A8 },
        { @"PlayerCameraManager", &o.PlayerCameraManager, 0x2C0 },
        { @"CameraCache",         &o.CameraCache,         0x1AF0},
        { @"POV",                 &o.POV,                 0x10  },
        { @"PlayerArray",         &o.PlayerArray,         0x2A8 },
        { @"PawnPrivate",         &o.PawnPrivate,         0x2A8 },
        { @"TeamOffset",          &o.TeamOffset,          0x3F0 },
        { @"Mesh",                &o.Mesh,                0x308 },
        { @"ComponentToWorld",    &o.ComponentToWorld,    0x1F0 },
        { @"BoneArray",           &o.BoneArray,           0x240 },
        { @"BoneArray+Num",       &o.BoneCount,           0x248 },
        { @"LastRenderTime",      &o.LastRenderTime,      0x2E8 },
        { @"ControlRotation",     &o.ControlRotation,     0x2A0 },
        { @"Weapon",              &o.Weapon,              0x9A0 },
        { @"ObjectName",          &o.ObjectName,          0x18  },
        { @"Health",              &o.Health,              0x0   },
        { @"NameStride",          &o.NameStride,          2     },
        { @"NameLenShift",        &o.NameLenShift,        6     },
        { @"ClassPrivate",        &o.ClassPrivate,        0x10  },
        { @"SuperStruct",         &o.SuperStruct,         0x40  },
        { @"Children",            &o.Children,            0x48  },
        { @"FieldNext",           &o.FieldNext,           0x20  },
        { @"FieldName",           &o.FieldName,           0x18  },
        { @"PEVtableIndex",       &o.PEVtableIndex,       0x42  },
    };
    for (auto& e : map) {
        id v = d[e.key];
        if (v) {
            *e.target = (u32)[v unsignedIntValue];
            [Config::explicitKeys addObject:e.key];
        }
    }
    Config::nameXorKey = numK(d, "NameXorKey", Config::nameXorKey);
}

static void loadWeapons(NSArray* arr) {
    WeaponProfile& def = Config::def; // static member: must qualify inside free functions
    for (NSDictionary* w in arr) {
        NSString* n = w[@"name"];
        if (!n.length) continue;
        WeaponProfile* p = new WeaponProfile(); // leaked by design: lives for process lifetime
        p->name   = n;
        p->fov    = flt(w, @"fov",    def.fov);
        p->smooth = flt(w, @"smooth", def.smooth);
        p->lock   = (int)num(w, @"lock", def.lock);
        p->speed  = flt(w, @"speed",  def.speed);
        p->leadMs = flt(w, @"leadMs", def.leadMs);
        [Config::weapons addObject:(id)CFBridgingRelease(p)];
    }
}

void Config::load() {
    weapons = [NSMutableArray new];
    sigs = [NSDictionary new];

    NSDictionary* root = nil;
    @try {
        NSString* p = [NSString stringWithFormat:@"/var/jb/share/InjectorDemo/config.plist"];
        root = [NSDictionary dictionaryWithContentsOfFile:p];
    } @catch (...) { root = nil; }

    if (!root) return; // compiled-in defaults in UE.h stand

    if (NSDictionary* o = root[@"offsets"]) loadOffsets(o);
    if (NSDictionary* s = root[@"sigs"])    sigs = [s copy];

    decryptMode     = (int)numK(root, "decryptMode", (u32)decryptMode);
    reactBaseMs     = fltK(root, "reactBaseMs", reactBaseMs);
    reactPerMeterMs = fltK(root, "reactPerMeterMs", reactPerMeterMs);
    jitterAmp       = fltK(root, "jitterAmp", jitterAmp);
    jitterVertMul   = fltK(root, "jitterVertMul", jitterVertMul);
    lockBreakSec    = fltK(root, "lockBreakSec", lockBreakSec);
    leadVisDamp     = fltK(root, "leadVisDamp", leadVisDamp);
    inertiaLag      = fltK(root, "inertiaLag", inertiaLag);
    inertiaCatch    = fltK(root, "inertiaCatch", inertiaCatch);
    overshootChance = fltK(root, "overshootChance", overshootChance);
    overshootTauMs  = fltK(root, "overshootTauMs", overshootTauMs);
    flickChance     = fltK(root, "flickChance", flickChance);
    fovGlobalMul    = fltK(root, "fovGlobalMul", fovGlobalMul);
    radarRange      = fltK(root, "radarRange", radarRange);
    touchGain       = fltK(root, "touchGain", touchGain);
    if (NSString* am = root[@"aimMode"]) aimTouch = [am isEqualToString:@"touch"];

    if (NSDictionary* d = root[@"default"]) {
        def.fov    = flt(d, @"fov",    def.fov);
        def.smooth = flt(d, @"smooth", def.smooth);
        def.lock   = (int)num(d, @"lock", def.lock);
        def.speed  = flt(d, @"speed",  def.speed);
        def.leadMs = flt(d, @"leadMs", def.leadMs);
    }
    if (NSArray* w = root[@"weapons"]) loadWeapons(w);
}

WeaponProfile* Config::match(NSString* weaponName) {
    if (!weaponName.length) return &def;
    for (id obj in weapons) { // array holds WeaponProfile* (C structs) as raw pointers
        WeaponProfile* p = (WeaponProfile*)obj;
        if ([weaponName localizedCaseInsensitiveContainsString:p->name]) return p;
    }
    return &def;
}
