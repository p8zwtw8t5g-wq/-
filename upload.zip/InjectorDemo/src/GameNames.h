// GameNames.h — class-name tables recovered from the reference "kiss" FloatDemo binary.
// Kiss identifies game entities by FName class-name matching, NOT hardcoded offsets.
// These are the actual strings it matches against in Valorant Mobile (国服).

#pragma once
#import <Foundation/Foundation.h>

// real player pawns (targets)
static NSArray* kPlayerClassNames = nil;
static inline NSArray* GameNames_players() {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        kPlayerClassNames = @[@"pawn", @"player", @"character", @"trainingrobot"];
    });
    return kPlayerClassNames;
}

// ability/ability-projectile actors — Kiss renders these as "warningObjects"
// (utility detection: bullets, recon, traps, cameras, fake players, teleport targets)
static NSArray* kAbilityClassNames = nil;
static inline NSArray* GameNames_abilities() {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        kAbilityClassNames = @[
            @"GAA_AGT_RE_C_BulletActor_C",       // Reyna
            @"BP_AGT_SO_C_UAV_C",                // Sova drone
            @"BP_AGT_SA_Q_BulletActor_C", @"BP_AGT_SA_Q_SlowOrbGroundActor_C", // Sage
            @"Actor_AGT_PH_E_Bullet_v2_C", @"BP_AGT_PH_Q_Projectile2_C",       // Phoenix
            @"BP_AGT_SO_E_ArrowBulletActor_C", @"BP_AGT_SO_Q_ArrowBulletActor_C",
            @"BP_AGT_BS_Q_BulletActor_C", @"BP_AGT_BS_C_BulletActor_C",        // Breach
            @"BP_AGT_RA_C_Robot_v2_C", @"AGT_RA_Q_BulletActor_C",              // Raze
            @"BP_AGT_SK_E_HawkCharacter_C",                                    // Skye hawk
            @"Actor_AGT_JE_C_Bullet_v2_C",                                     // Jett
            @"GA_AGT_VI_C_Bullet_C", @"BP_AGT_VI_E_ProjectileActor_C",
            @"GAA_AGT_VI_Q_BulletActor_C",                                     // Viper
            @"BP_AGT_CY_C_Trapwire_C", @"BP_AGT_CY_E_Spycam_C",
            @"GAA_AGT_CY_Q_BulletActor_C",                                     // Cypher
            @"BP_AGT_KI_E_Robot_C", @"BP_AGT_OM_Q_BulletActor_C",              // KAY/O, Omen
            @"GAA_AGT_YO_C_FakePlayer_C", @"GAA_AGT_YO_E_TransportTarget_C",   // Yoru
            @"BP_AGT_KA_C_BulletActor_C", @"BP_AGT_KA_E_BulletActor_C",
            @"BP_AGT_KA_Q_BulletActor_C",                                      // KAY/O variants
            @"Robot_AGT_CH_C_C", @"BP_AGT_CH_E_TeleportActor_C",               // Chamber
            @"GA_AGT_NE_X_Sprint_C",                                           // Neon
            @"BP_AGT_FA_E_Haunt_C", @"BP_AGT_FA_Q_BulletActor_C",              // Fade
            @"BP_AGT_GE_C_MoshPitBulletActor_C", @"BP_AGT_GE_Q_WingMan_C",     // Gekko
            @"BP_AGT_IS_C_WallActor_C",                                        // Iso
            @"Actor_AGT_CL_Q_Bullet_C",                                        // Clove
            @"BP_AGT_HA_C_SplashGrenade_C",                                    // Harbor
            @"BP_AGT_VY_C_BulletActor_C",                                      // Vyse
        ];
    });
    return kAbilityClassNames;
}

// feature keys observed in Kiss settings plist (com.91spnb.fuck.settings.plist):
//   espEnabled skeleton showBox healthBar mapName antiRecording name distance
//   armor agentIcon weaponIcon losLine warningObjects localPhysX antenna
//   backEnemy fovBackEnemy touchAim boneDecrypt boxDecrypt triggerEnabled
//   touchSensitivity aimFov predictScale predictBoost triggerSize triggerBtnX/Y fireBtnX/Y
// Features we don't have yet worth porting: antiRecording (hide overlay from
// screen capture), antenna (overhead marker line), warningObjects (the table above).

// agent prefix (from "BP_AGT_XX_C..." class names) -> agent icon file
// (prefix codes confirmed from kiss's ability-actor class list)
static NSDictionary* kAgentPrefixToIcon = nil;
static inline NSDictionary* GameNames_agentMap() {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        kAgentPrefixToIcon = @{
            @"RE": @"Reyna",   @"SO": @"Sova",    @"SA": @"Sage",   @"PH": @"Phoenix",
            @"BS": @"Breach",  @"RA": @"Raze",    @"SK": @"Skye",   @"JE": @"Jett",
            @"VI": @"Viper",   @"CY": @"Cypher",  @"KI": @"Killjoy",@"OM": @"Omen",
            @"YO": @"Yoru",    @"KA": @"KAYO",    @"CH": @"Chamber",@"NE": @"Neon",
            @"FA": @"Fade",    @"GE": @"Gekko",   @"IS": @"Iso",    @"CL": @"Clove",
            @"HA": @"Harbor",  @"VY": @"Vyse",    @"DD": @"Deadlock",@"TJ": @"Tejo",
        };
    });
    return kAgentPrefixToIcon;
}

// "AGT_XX" extraction from a class name like "BP_AGT_SO_C" or "BP_AGT_SO_C_UAV_C"
static inline NSString* GameNames_agentPrefix(NSString* className) {
    if (!className) return nil;
    NSRange r = [className rangeOfString:@"AGT_"];
    if (r.location == NSNotFound || r.location + 8 > className.length) return nil;
    NSString* rest = [className substringFromIndex:r.location + 4];
    if (rest.length < 2) return nil;
    return [rest substringToIndex:2];
}

static inline NSString* GameNames_agentIcon(NSString* className) {
    NSString* pfx = GameNames_agentPrefix(className);
    if (!pfx) return nil;
    NSString* agent = GameNames_agentMap()[pfx];
    return agent ? [agent stringByAppendingString:@".png"] : nil;
}

// weapon icon: substring match of known weapon keys inside the object name
static NSArray* kWeaponIconNames = nil;
static inline NSString* GameNames_weaponIcon(NSString* weaponObjName) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        kWeaponIconNames = @[@"Vandal", @"Phantom", @"Operator", @"Guardian", @"Bulldog",
                             @"Marshal", @"Outlaw", @"Sheriff", @"Spectre", @"Stinger",
                             @"Classic", @"Frenzy", @"Ghost", @"Shorty", @"Bucky",
                             @"Judge", @"Ares", @"Odin", @"Melee", @"Headhunter",
                             @"ChamberUlt", @"Bandit"];
    });
    if (!weaponObjName) return nil;
    NSString* low = weaponObjName.lowercaseString;
    for (NSString* w in kWeaponIconNames)
        if ([low containsString:w.lowercaseString]) return [w stringByAppendingString:@".png"];
    return nil;
}
