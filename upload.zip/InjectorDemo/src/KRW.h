#pragma once
#import "UE.h"
#import <Foundation/Foundation.h>
#import <mach/mach.h>

// cross-process memory engine ("kiss model"):
//   find the game by process name -> task_for_pid -> mach_vm_read/write.
// no injection, no tweak, nothing for Choicy/ACE-injection to see.

extern mach_port_t g_taskPort;   // game task port (MACH_PORT_NULL = not attached)
extern int         g_gamePid;
extern u64         g_gameBase;   // game __TEXT base
extern u64         g_gameTextSize;
extern bool        g_aimTrigger; // hold-to-aim (overlay ball / aim button)

bool krwAttach();                // (re)attach; cheap to call every frame, caches
void krwDetach();

bool rd(u64 addr, void* out, u64 sz);            // remote read
bool wr(u64 addr, const void* src, u64 sz);      // remote write

template<typename T> static inline T rdv(u64 addr, T dflt = T{}) {
    T v; if (!rd(addr, &v, sizeof(T))) return dflt; return v;
}

// walk the game's vm regions; used by the remote sig scan
bool krwRegions(u64& textBase, u64& textSize, u64& dataBase, u64& dataSize);
