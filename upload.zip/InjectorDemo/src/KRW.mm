#import "KRW.h"
#import <sys/sysctl.h>
#import <string.h>
#import <stdlib.h>
#import <signal.h>

// iPhoneOS SDK ships no libproc.h — declare what we use by hand
#define PROC_ALL_PIDS 1
extern "C" {
int proc_listpids(uint32_t type, uint32_t typeinfo, void* buffer, int buffersize);
int proc_name(int pid, void* buffer, uint32_t buffersize);
}

mach_port_t g_taskPort = MACH_PORT_NULL;
int         g_gamePid  = -1;
u64         g_gameBase = 0;
u64         g_gameTextSize = 0;
bool        g_aimTrigger = false;

// process names the game is known to run as (substring match, case-insensitive)
static NSArray* g_gameNames = nil;

static void initNames() {
    if (g_gameNames) return;
    NSMutableArray* m = [NSMutableArray arrayWithArray:
        @[@"codev", @"tpumpkv2", @"valorant", @"client", @"game"];
    NSString* extra = [[NSUserDefaults standardUserDefaults] stringForKey:@"id_game_name"];
    if (extra.length) [m insertObject:extra atIndex:0];
    g_gameNames = m;
}

void krwDetach() {
    if (g_taskPort != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), g_taskPort);
    g_taskPort = MACH_PORT_NULL;
    g_gamePid = -1; g_gameBase = 0; g_gameTextSize = 0;
}

static bool findGamePid() {
    initNames();
    int pids[4096];
    int n = proc_listpids(PROC_ALL_PIDS, 0, pids, sizeof(pids)) / 4;
    if (n <= 0) return false;
    char name[2 * MAXCOMLEN];
    for (int i = n - 1; i >= 0; --i) {   // newest processes first
        if (!pids[i] || pids[i] == getpid()) continue;
        memset(name, 0, sizeof(name));
        if (proc_name(pids[i], name, sizeof(name)) <= 0) continue;
        NSString* pn = [NSString stringWithUTF8String:name];
        if (!pn.length) continue;
        for (NSString* want in g_gameNames)
            if ([pn rangeOfString:want options:NSCaseInsensitiveSearch].location != NSNotFound) {
                g_gamePid = pids[i];
                return true;
            }
    }
    return false;
}

bool krwRegions(u64& textBase, u64& textSize, u64& dataBase, u64& dataSize) {
    textBase = textSize = dataBase = dataSize = 0;
    if (g_taskPort == MACH_PORT_NULL) return false;
    mach_vm_address_t a = 0;
    kern_return_t kr = KERN_SUCCESS;
    while (kr == KERN_SUCCESS) {
        mach_vm_size_t sz = 0;
        vm_region_basic_info_data_64_t info;
        mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
        mach_port_t objname = MACH_PORT_NULL;
        a = (a + 0xFFFF) & ~(mach_vm_address_t)0xFFFF; // page up
        kr = mach_vm_region(g_taskPort, &a, &sz, VM_REGION_BASIC_INFO_64,
                            (vm_region_info_t)&info, &cnt, &objname);
        if (kr != KERN_SUCCESS) break;
        bool exec = (info.protection & VM_PROT_EXECUTE) != 0;
        bool rw   = (info.protection & VM_PROT_READ) && (info.protection & VM_PROT_WRITE);
        // main binary __TEXT: first exec region whose file offset is 0
        if (!textBase && exec && info.offset == 0) {
            textBase = a; textSize = sz;
        }
        // first sizable rw- region after text = __DATA candidate
        if (textBase && !dataBase && rw && a > textBase && sz >= 0x10000) {
            dataBase = a; dataSize = sz;
        }
        if (textBase && dataBase) break;
        a += sz;
        if (a > 0x10000000000ULL) break; // sanity cap
    }
    return textBase != 0;
}

bool krwAttach() {
    static f64 nextTry = 0;
    f64 now = [NSDate date].timeIntervalSince1970;
    if (g_taskPort != MACH_PORT_NULL) {
        // liveness: signal-0 probe
        if (kill(g_gamePid, 0) == 0) return g_gameBase != 0;
        krwDetach(); // game died
    }
    if (now < nextTry) return false;
    nextTry = now + 1.0;

    if (!findGamePid()) return false;
    task_t t = MACH_PORT_NULL;
    if (task_for_pid(mach_task_self(), g_gamePid, &t) != KERN_SUCCESS || t == MACH_PORT_NULL) {
        g_gamePid = -1;
        return false;
    }
    g_taskPort = t;
    u64 db, ds;
    if (!krwRegions(g_gameBase, g_gameTextSize, db, ds)) {
        krwDetach();
        return false;
    }
    return true;
}

bool rd(u64 addr, void* out, u64 sz) {
    if (!addr || g_taskPort == MACH_PORT_NULL || !out || !sz) return false;
    u8* dst = (u8*)out;
    u64 done = 0;
    while (done < sz) {
        u64 cur = addr + done;
        u64 pageEnd = (cur + 0x1000) & ~(u64)0xFFF;
        u64 chunk = MIN(sz - done, pageEnd - cur);
        vm_size_t got = 0;
        if (mach_vm_read_overwrite(g_taskPort, (mach_vm_address_t)cur, chunk,
                                   (mach_vm_address_t)(dst + done), &got) != KERN_SUCCESS || got != chunk)
            return false;
        done += chunk;
    }
    return true;
}

bool wr(u64 addr, const void* src, u64 sz) {
    if (!addr || g_taskPort == MACH_PORT_NULL || !src || !sz) return false;
    const u8* p = (const u8*)src;
    u64 done = 0;
    while (done < sz) {
        u64 cur = addr + done;
        u64 pageEnd = (cur + 0x1000) & ~(u64)0xFFF;
        u64 chunk = MIN(sz - done, pageEnd - cur);
        if (mach_vm_write(g_taskPort, (mach_vm_address_t)cur,
                          (vm_offset_t)(p + done), (mach_msg_type_number_t)chunk) != KERN_SUCCESS)
            return false;
        done += chunk;
    }
    return true;
}
