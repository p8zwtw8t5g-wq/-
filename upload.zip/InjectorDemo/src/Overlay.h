#pragma once
#import <UIKit/UIKit.h>
#import "UE.h"

// one frame of world state, built by GameRead, consumed by overlay + aim
struct Entity {
    bool        used = false;
    bool        alive = true;    // health-based (Health off -> assumed alive)
    bool        visible = false;
    bool        boneOk = false;
    int         team = 0;
    f32         dist = 0.f;      // meters
    f32         hp = -1.f;
    uintptr_t   pawn = 0;
    FVec        origin;          // pelvis/comp origin world
    FVec        head;
    FVec        vel;             // m/s estimated
    FVec        bones[BONE_MAX]; // world space
    int         boneCount = 0;
    u64         id = 0;          // pawn ptr as key
    // internal
    f32         lastRenderPrev = 0.f;
    f64         lastSeenT = 0;
};

struct Frame {
    Entity ents[32];
    int    entCount = 0;
    FVec   camLoc;
    FRot   camRot;
    f32    fov = 90.f;
    int    screenW = 0, screenH = 0;
    f64    now = 0;
    uintptr_t localPawn = 0;
    int    localTeam = -1;
    bool   ready = false;
    bool   localDead = false;   // health-based, hides ESP while dead/spectating
};

extern Frame g_frame;

// master switches, wired to the floating panel
struct Switches {
    bool master = true;
    bool esp    = true;
    bool aim    = true;
    bool safeMode = false;   // ESP-only
    bool radar  = true;
    int  lockPart = -1;      // -1 = weapon profile default, else 0/1/2
    float fovMul = 1.f;
};
extern Switches g_sw;

@interface ESPWindow : UIWindow
@end

void startOverlay();
void requestSigDump();
