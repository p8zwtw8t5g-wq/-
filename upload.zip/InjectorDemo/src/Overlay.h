#pragma once
#import <UIKit/UIKit.h>
#import "UE.h"

// one frame of world state, built by GameRead, consumed by overlay + aim
struct Entity {
    bool        used = false;
    bool        alive = true;    // health-based (Health off -> assumed alive)
    bool        visible = false;
    bool        boneOk = false;
    bool        bot = false;     // trainingrobot / non-player pawn class
    int         team = 0;
    f32         dist = 0.f;      // meters
    f32         hp = -1.f;
    f32         armor = -1.f;    // kiss-parity: -1 = unavailable
    uintptr_t   pawn = 0;
    FVec        origin;          // pelvis/comp origin world
    FVec        head;
    FVec        vel;             // m/s estimated
    FVec        bones[BONE_MAX]; // world space
    int         boneCount = 0;
    u64         id = 0;          // pawn ptr as key
    NSString*   agentIcon = nil; // "Reyna.png" etc (nil = unknown)
    NSString*   weaponIcon = nil;// "Vandal.png" etc (nil = unknown)
    // internal
    f32         lastRenderPrev = 0.f;
    f64         lastSeenT = 0;
};

// ability/utility actors (warningObjects, kiss parity)
struct Warn {
    FVec        pos;
    NSString*   cls;   // matched class name
};

struct Frame {
    Entity ents[32];
    int    entCount = 0;
    Warn   warns[48];
    int    warnCount = 0;
    FVec   camLoc;
    FRot   camRot;
    f32    fov = 90.f;
    int    screenW = 0, screenH = 0;
    f64    now = 0;
    uintptr_t localPawn = 0;
    int    localTeam = -1;
    bool   ready = false;
    bool   localDead = false;   // health-based, hides ESP while dead/spectating
};

extern Frame g_frame;
extern NSString* g_skeletonPairs;   // Reader.mm: "a,b|c,d" bone index pairs

// master switches, wired to the floating panel
struct Switches {
    bool master = true;
    bool esp    = true;
    bool aim    = true;
    bool safeMode = false;   // ESP-only
    bool radar  = true;
    // kiss-parity switches
    bool icons  = true;      // agent/weapon icons next to boxes
    bool antenna = true;     // overhead marker line
    bool losLine = true;     // crosshair->enemy line, colored by visibility
    bool warning = true;     // ability actors as warning markers
    bool backEnemy = true;   // behind-you indicators
    bool armor  = true;      // armor bar (needs Armor offset != 0)
    bool antiRec = false;    // hide canvas from screen recording (secure-entry wrap)
    bool noBotAim = false;   // never aim at bots/training dummies
    int  lockPart = -1;      // -1 = weapon profile default, else 0/1/2
    float lockShift = 0.f;   // unified height trim, meters (+head .. -chest)
    float fovMul = 1.f;
    bool value(int tag) const {   // panel switch tag -> current state
        switch (tag) {
            case 0: return master;  case 1: return esp;     case 2: return aim;
            case 3: return radar;   case 4: return safeMode;
            case 5: return icons;   case 6: return antenna; case 7: return losLine;
            case 8: return warning; case 9: return backEnemy;
            case 10: return armor;  case 11: return antiRec; case 12: return noBotAim;
        }
        return false;
    }
};
extern Switches g_sw;
extern bool g_aimTrigger;   // hold-to-aim: floating ball press or aim button

// builds the full overlay UI into the app's own window (cross-process mode:
// our window is the canvas — run the app in Slide Over over the game)
void startOverlay(UIWindow* win);
UIView* g_rootCanvas();
void buildFrame();   // Reader.mm: remote world read -> g_frame
void syncOffsets();  // Reader.mm
void doSigDump();    // Reader.mm
void requestSigDump();
