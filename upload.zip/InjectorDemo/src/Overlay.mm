#import "Overlay.h"
#import "Config.h"
#import "Aim.h"
#import "KRW.h"
#import "AutoScan.h"
#import "SigScan.h"
#import "StrObf.h"
#import "GameNames.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

Frame g_frame;
Switches g_sw;

void buildFrame();              // Reader.mm: remote world read -> g_frame
void syncOffsets();             // Reader.mm
WeaponProfile* currentWeaponProfile();

static float randf1() { return (float)arc4random() / (float)UINT32_MAX * 2.f - 1.f; }

// ---------------------------------------------------------------- icon cache
// theos copies resource pngs flat into the .app bundle -> imageNamed works
static NSMutableDictionary* g_iconCache = nil;
static UIImage* iconFor(NSString* file) {
    if (!file) return nil;
    if (!g_iconCache) g_iconCache = [NSMutableDictionary new];
    UIImage* im = g_iconCache[file];
    if (!im) {
        im = [UIImage imageNamed:file];
        if (im) g_iconCache[file] = im;
    }
    return im;
}

// camera basis (matches Aim.mm) for behind-detection
static void oCamAxes(const FRot& r, FVec& fwd, FVec& right) {
    const f32 d = 3.14159265f / 180.f;
    f32 sp = sinf(r.pitch*d), cp = cosf(r.pitch*d);
    f32 sy = sinf(r.yaw*d),   cy = cosf(r.yaw*d);
    fwd   = { cp*cy, cp*sy, sp };
    right = { -sy, cy, 0.f };
}
static bool isBehind(const Frame& f, const FVec& w, f32& sideX) {
    FVec fwd, right; oCamAxes(f.camRot, fwd, right);
    FVec rel = { w.x - f.camLoc.x, w.y - f.camLoc.y, w.z - f.camLoc.z };
    f32 z = rel.x*fwd.x + rel.y*fwd.y + rel.z*fwd.z;
    sideX = rel.x*right.x + rel.y*right.y;
    return z < 0.f;
}

// ---------------------------------------------------------------- canvas view
// draws: crosshair, aim fov, ESP boxes/skeleton/hp/armor/dist, agent+weapon
// icons, antenna, los lines, ability warnings, back-enemy arrows, radar.

@interface ESPCanvasView : UIView
@property (nonatomic, strong) UIButton* gear;
@property (nonatomic, strong) UIView* panel;
@property (nonatomic, strong) UIView* ball;
@property (nonatomic, strong) UIButton* startBtn;
@property (nonatomic, strong) UIButton* pill;   // collapsed menu ("dynamic island" style)
@end

@implementation ESPCanvasView

- (void)drawRect:(CGRect)rect {
    CGContextRef c = UIGraphicsGetCurrentContext();
    CGContextClearRect(c, rect);
    CGContextSetFillColorWithColor(c, [UIColor.blackColor colorWithAlphaComponent:0.25].CGColor);
    CGContextFillRect(c, rect);

    Frame& f = g_frame;
    CGSize scr = self.bounds.size;
    if (!g_sw.master) { [self drawStatus:c line:g_aimTrigger ? @"AIM HELD" : @"paused"]; return; }

    // game -> canvas mapping (fit, centered)
    f32 gameW = (f32)(f.screenW ?: 834), gameH = (f32)(f.screenH ?: 1194);
    f32 scl = MIN(scr.width / gameW, scr.height / gameH);
    f32 offX = (scr.width  - gameW * scl) * 0.5f;
    f32 offY = (scr.height - gameH * scl) * 0.5f;

    if (!f.ready) {
        [self drawStatus:c line:g_aimTrigger ? @"AIM HELD (no frame)" : @"waiting for game frame..."];
        return;
    }
    if (f.localDead) { [self drawRadar:c dim:YES mapX:offX mapY:offY scale:scl]; return; }

    f32 cx = offX + gameW * 0.5f * scl, cy = offY + gameH * 0.5f * scl;

    // crosshair
    CGContextSetStrokeColorWithColor(c, [UIColor.systemGreenColor colorWithAlphaComponent:0.7].CGColor);
    CGContextSetLineWidth(c, 1.f);
    CGContextMoveToPoint(c, cx - 6, cy); CGContextAddLineToPoint(c, cx + 6, cy);
    CGContextMoveToPoint(c, cx, cy - 6); CGContextAddLineToPoint(c, cx, cy + 6);
    CGContextStrokePath(c);

    if (g_sw.radar) [self drawRadar:c dim:NO mapX:offX mapY:offY scale:scl];

    // aim fov circle (scaled)
    WeaponProfile* wp = currentWeaponProfile();
    f32 fovR = wp->fov * Config::fovGlobalMul * g_sw.fovMul * scl;
    CGContextSetStrokeColorWithColor(c, [UIColor.systemYellowColor colorWithAlphaComponent:0.25].CGColor);
    CGContextStrokeEllipseInRect(c, CGRectMake(cx - fovR, cy - fovR, fovR * 2, fovR * 2));

    for (int i = 0; i < f.entCount; ++i) {
        Entity& e = f.ents[i];
        if (!e.used || !e.alive) continue;
        bool friendly = (f.localTeam >= 0 && e.team == f.localTeam && e.team != 0);
        UIColor* col = friendly ? [UIColor.systemBlueColor colorWithAlphaComponent:0.9]
                                : (e.visible ? [UIColor.systemRedColor colorWithAlphaComponent:0.95]
                                             : [UIColor.systemOrangeColor colorWithAlphaComponent:0.75]);

        f32 bx, by, hx, hy;
        bool onScreen = w2sFrame(f, e.origin, bx, by) && w2sFrame(f, e.head, hx, hy);
        if (!onScreen) {
            // backEnemy: indicator arrow for enemies behind the camera
            if (g_sw.backEnemy && !friendly) {
                f32 sideX;
                if (isBehind(f, e.origin, sideX)) {
                    f32 ax = cx + (sideX >= 0 ? 1 : -1) * MIN(scr.width * 0.5f - 18, 46 * scl + 30);
                    f32 ay = scr.height - 90;
                    CGContextSetFillColorWithColor(c, [UIColor.systemRedColor colorWithAlphaComponent:0.85].CGColor);
                    CGContextMoveToPoint(c, sideX >= 0 ? ax + 10 : ax - 10, ay);
                    CGContextAddLineToPoint(c, ax, ay - 6);
                    CGContextAddLineToPoint(c, ax, ay + 6);
                    CGContextClosePath(c);
                    CGContextFillPath(c);
                    NSString* t = [NSString stringWithFormat:@"%.0f", e.dist];
                    [t drawAtPoint:CGPointMake(ax - 6, ay + 8)
                     withAttributes:@{NSFontAttributeName: [UIFont boldSystemFontOfSize:8],
                                      NSForegroundColorAttributeName: UIColor.systemRedColor}];
                }
            }
            continue;
        }
        // map into canvas space
        auto M = [&](f32& v, f32 val, f32 org) { v = org + val * scl; };
        f32 ox, oy, mhx, mhy; M(ox, bx, offX); M(oy, by, offY); M(mhx, hx, offX); M(mhy, hy, offY);
        f32 h = fabsf(oy - mhy) * 2.15f;
        f32 bw = h * 0.45f;

        // losLine: crosshair -> enemy, colored by visibility (kiss parity)
        if (g_sw.losLine && !friendly) {
            CGContextSetStrokeColorWithColor(c, (e.visible
                ? [UIColor.systemGreenColor colorWithAlphaComponent:0.4]
                : [UIColor.systemOrangeColor colorWithAlphaComponent:0.3]).CGColor);
            CGContextSetLineWidth(c, 1.f);
            CGContextMoveToPoint(c, cx, cy);
            CGContextAddLineToPoint(c, ox + bw * 0.5f, oy + h * 0.5f);
            CGContextStrokePath(c);
        }

        CGContextSetStrokeColorWithColor(c, col.CGColor);
        CGContextSetLineWidth(c, 1.5f);
        CGContextStrokeRect(c, CGRectMake(ox, oy - h * 0.06f, bw, h));

        if (e.boneOk) [self drawSkeleton:c ent:e color:col mapX:offX mapY:offY scale:scl];

        CGContextSetFillColorWithColor(c, col.CGColor);
        CGContextFillEllipseInRect(c, CGRectMake(mhx - 2, mhy - 2, 4, 4));

        // antenna: overhead marker line (kiss parity)
        if (g_sw.antenna) {
            CGContextSetStrokeColorWithColor(c, [UIColor.systemCyanColor colorWithAlphaComponent:0.7].CGColor);
            CGContextSetLineWidth(c, 1.f);
            CGContextMoveToPoint(c, mhx, mhy);
            CGContextAddLineToPoint(c, mhx, mhy - 34);
            CGContextStrokePath(c);
            CGContextSetFillColorWithColor(c, [UIColor.systemCyanColor colorWithAlphaComponent:0.85].CGColor);
            CGContextFillEllipseInRect(c, CGRectMake(mhx - 2.5, mhy - 40, 5, 5));
        }

        // hp bar
        if (e.hp >= 0.f) {
            f32 frac = e.hp / 100.f; if (frac > 1) frac = 1;
            CGContextSetFillColorWithColor(c, [UIColor.blackColor colorWithAlphaComponent:0.6].CGColor);
            CGContextFillRect(c, CGRectMake(ox - 6, oy, 3, h));
            CGContextSetFillColorWithColor(c, [UIColor.systemGreenColor colorWithAlphaComponent:0.9].CGColor);
            CGContextFillRect(c, CGRectMake(ox - 6, oy + h * (1 - frac), 3, h * frac));
        }
        // armor bar (kiss parity)
        if (g_sw.armor && e.armor >= 0.f) {
            f32 frac = e.armor / 100.f; if (frac > 1) frac = 1;
            CGContextSetFillColorWithColor(c, [UIColor.blackColor colorWithAlphaComponent:0.6].CGColor);
            CGContextFillRect(c, CGRectMake(ox - 11, oy, 3, h));
            CGContextSetFillColorWithColor(c, [UIColor.systemGrayColor colorWithAlphaComponent:0.9].CGColor);
            CGContextFillRect(c, CGRectMake(ox - 11, oy + h * (1 - frac), 3, h * frac));
        }

        // right-side info column: agent icon, weapon icon, distance, BOT tag
        f32 rx = ox + bw + 4;
        if (g_sw.icons) {
            UIImage* ag = iconFor(e.agentIcon);
            if (ag) [ag drawInRect:CGRectMake(rx, oy, 26, 26)];
            UIImage* wg = iconFor(e.weaponIcon);
            if (wg) [wg drawInRect:CGRectMake(rx, oy + 28, 34, 18)];
        }
        if (e.dist > 0.1f) {
            NSString* t = [NSString stringWithFormat:@"%.0fm", e.dist];
            [t drawAtPoint:CGPointMake(rx, oy + (g_sw.icons ? 48 : 0))
            withAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:9],
                             NSForegroundColorAttributeName: col}];
        }
        if (e.bot) {
            [@"BOT" drawAtPoint:CGPointMake(rx, oy - 12)
             withAttributes:@{NSFontAttributeName: [UIFont boldSystemFontOfSize:8],
                              NSForegroundColorAttributeName: [UIColor.systemYellowColor colorWithAlphaComponent:0.9]}];
        }
    }

    // warningObjects: ability actors (kiss parity)
    if (g_sw.warning) {
        for (int i = 0; i < f.warnCount; ++i) {
            Warn& w = f.warns[i];
            f32 wx, wy;
            if (!w2sFrame(f, w.pos, wx, wy)) continue;
            f32 px = offX + wx * scl, py = offY + wy * scl;
            CGContextSetFillColorWithColor(c, [UIColor.systemYellowColor colorWithAlphaComponent:0.8].CGColor);
            CGContextMoveToPoint(c, px, py - 6);
            CGContextAddLineToPoint(c, px - 5, py + 4);
            CGContextAddLineToPoint(c, px + 5, py + 4);
            CGContextClosePath(c);
            CGContextFillPath(c);
        }
    }
    [self drawStatus:c line:g_aimTrigger ? @"AIM HELD" : @""];
}

- (void)drawStatus:(CGContextRef)c line:(NSString*)msg {
    if (!msg.length) return;
    NSDictionary* at = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:11],
                         NSForegroundColorAttributeName: [UIColor.systemRedColor colorWithAlphaComponent:0.8]};
    [msg drawAtPoint:CGPointMake(12, self.bounds.size.height - 40) withAttributes:at];
}

- (void)drawSkeleton:(CGContextRef)c ent:(Entity&)e color:(UIColor*)col mapX:(f32)mapX mapY:(f32)mapY scale:(f32)scl {
    if (g_skeletonPairs.length == 0) return;
    CGContextSetStrokeColorWithColor(c, col.CGColor);
    CGContextSetLineWidth(c, 1.f);
    for (NSString* pair in [g_skeletonPairs componentsSeparatedByString:@","]) {
        NSArray* ij = [pair componentsSeparatedByString:@"-"];
        if (ij.count != 2) continue;
        int a = [(NSString*)ij[0] intValue], b = [(NSString*)ij[1] intValue];
        if (a < 0 || b < 0 || a >= e.boneCount || b >= e.boneCount) continue;
        f32 ax, ay, bxx, byy;
        if (!w2sFrame(g_frame, e.bones[a], ax, ay)) continue;
        if (!w2sFrame(g_frame, e.bones[b], bxx, byy)) continue;
        CGContextMoveToPoint(c, mapX + ax * scl, mapY + ay * scl);
        CGContextAddLineToPoint(c, mapX + bxx * scl, mapY + byy * scl);
    }
    CGContextStrokePath(c);
}

- (void)drawRadar:(CGContextRef)c dim:(BOOL)dim mapX:(f32)mapX mapY:(f32)mapY scale:(f32)scl {
    (void)mapX; (void)mapY; (void)scl;
    Frame& f = g_frame;
    f32 R = 56.f, alpha = dim ? 0.25f : 0.85f;
    CGPoint cc = CGPointMake(self.bounds.size.width * 0.5f, 70.f);

    CGContextSetFillColorWithColor(c, [UIColor.blackColor colorWithAlphaComponent:0.35 * alpha].CGColor);
    CGContextFillEllipseInRect(c, CGRectMake(cc.x - R, cc.y - R, R * 2, R * 2));
    CGContextSetStrokeColorWithColor(c, [UIColor.whiteColor colorWithAlphaComponent:0.3 * alpha].CGColor);
    CGContextSetLineWidth(c, 1.f);
    CGContextStrokeEllipseInRect(c, CGRectMake(cc.x - R, cc.y - R, R * 2, R * 2));
    CGContextMoveToPoint(c, cc.x - R, cc.y); CGContextAddLineToPoint(c, cc.x + R, cc.y);
    CGContextMoveToPoint(c, cc.x, cc.y - R); CGContextAddLineToPoint(c, cc.x, cc.y + R);
    CGContextStrokePath(c);

    CGContextSetFillColorWithColor(c, [UIColor.whiteColor colorWithAlphaComponent:0.10 * alpha].CGColor);
    CGContextMoveToPoint(c, cc.x, cc.y);
    CGContextAddArc(c, cc.x, cc.y, R * 0.85f, -(f32)M_PI_2 - 0.6f, -(f32)M_PI_2 + 0.6f, 0);
    CGContextClosePath(c);
    CGContextFillPath(c);

    const f32 d = (f32)M_PI / 180.f;
    f32 yaw = f.camRot.yaw * d, sy = sinf(yaw), cyy = cosf(yaw);
    f32 scale = R / Config::radarRange;

    for (int i = 0; i < f.entCount; ++i) {
        Entity& e = f.ents[i];
        if (!e.used || !e.alive) continue;
        bool friendly = (f.localTeam >= 0 && e.team == f.localTeam && e.team != 0);
        f32 wx = e.origin.x - f.camLoc.x, wy = e.origin.y - f.camLoc.y;
        f32 rx =  wx * cyy + wy * sy;
        f32 ry = -wx * sy  + wy * cyy;
        f32 px = cc.x + rx * scale;
        f32 py = cc.y - ry * scale;
        f32 dd = hypotf(px - cc.x, py - cc.y);
        if (dd > R - 3) {
            px = cc.x + (px - cc.x) / dd * (R - 3);
            py = cc.y + (py - cc.y) / dd * (R - 3);
        }
        UIColor* col = friendly ? [UIColor.systemBlueColor colorWithAlphaComponent:alpha]
                     : (e.visible ? [UIColor.systemRedColor colorWithAlphaComponent:alpha]
                                  : [UIColor.systemOrangeColor colorWithAlphaComponent:0.7f * alpha]);
        CGContextSetFillColorWithColor(c, col.CGColor);
        CGContextFillEllipseInRect(c, CGRectMake(px - 3, py - 3, 6, 6));
    }

    // ability warnings on radar too
    if (g_sw.warning && !dim) {
        CGContextSetFillColorWithColor(c, [UIColor.systemYellowColor colorWithAlphaComponent:0.7].CGColor);
        for (int i = 0; i < f.warnCount; ++i) {
            Warn& w = f.warns[i];
            f32 wx = w.pos.x - f.camLoc.x, wy = w.pos.y - f.camLoc.y;
            f32 rx =  wx * cyy + wy * sy;
            f32 ry = -wx * sy  + wy * cyy;
            f32 px = cc.x + rx * scale, py = cc.y - ry * scale;
            f32 dd = hypotf(px - cc.x, py - cc.y);
            if (dd > R - 3) continue;
            CGContextFillEllipseInRect(c, CGRectMake(px - 2, py - 2, 4, 4));
        }
    }

    CGContextSetFillColorWithColor(c, [UIColor.systemGreenColor colorWithAlphaComponent:alpha].CGColor);
    CGContextFillEllipseInRect(c, CGRectMake(cc.x - 2.5, cc.y - 2.5, 5, 5));
}

@end

// ---------------------------------------------------------------- floating ball
// hold = aim trigger, tap = toggle panel, drag (panel open) = reposition

@interface BallView : UIView
@property (nonatomic, assign) double downT;
@property (nonatomic, assign) CGPoint downP;
@property (nonatomic, assign) BOOL dragging;
@end

@implementation BallView
- (void)touchesBegan:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {
    g_aimTrigger = true;
    self.downT = [NSDate date].timeIntervalSince1970;
    self.downP = self.center;
    self.alpha = 0.55;
}
- (void)touchesEnded:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {
    g_aimTrigger = false;
    self.alpha = 1.0;
    double dt = [NSDate date].timeIntervalSince1970 - self.downT;
    CGPoint moved = CGPointMake(self.center.x - self.downP.x, self.center.y - self.downP.y);
    if (dt < 0.25 && hypot(moved.x, moved.y) < 12) {
        ESPCanvasView* root = (ESPCanvasView*)self.superview;
        root.panel.hidden = !root.panel.hidden;
    }
}
- (void)touchesCancelled:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {
    g_aimTrigger = false;
    self.alpha = 1.0;
}
- (void)dragWith:(UIPanGestureRecognizer*)g {
    CGPoint tr = [g translationInView:self.superview];
    if (g.state == UIGestureRecognizerStateChanged) {
        // small jitter while holding to aim stays a hold; a real move (>12px)
        // turns into a drag and cancels the aim trigger
        if (!self.dragging && hypot(tr.x, tr.y) > 12) {
            self.dragging = YES;
            g_aimTrigger = false;
            self.alpha = 0.80;
        }
        if (!self.dragging) return;
        CGRect sc = self.superview.bounds;
        CGFloat nx = MIN(MAX(self.center.x + tr.x, 30), sc.size.width - 30);
        CGFloat ny = MIN(MAX(self.center.y + tr.y, 60), sc.size.height - 30);
        self.center = CGPointMake(nx, ny);
        [g setTranslation:CGPointZero inView:self.superview];
    } else if (g.state == UIGestureRecognizerStateEnded && self.dragging) {
        self.dragging = NO;
        self.alpha = 1.0;
        [[NSUserDefaults standardUserDefaults] setDouble:self.center.x forKey:@"id_ball_x"];
        [[NSUserDefaults standardUserDefaults] setDouble:self.center.y forKey:@"id_ball_y"];
    }
}
@end

static ESPCanvasView* g_root = nil;

// ---------------------------------------------------------------- antiRecording
// secure-text-entry wrap: content inside a UITextField's secure canvas is
// excluded from screenshots and screen recordings (kiss "antiRecording")
static UITextField* g_secField = nil;

static void applyAntiRec(UIWindow* win, BOOL on) {
    if (on && !g_secField) {
        g_secField = [[UITextField alloc] initWithFrame:win.bounds];
        g_secField.secureTextEntry = YES;
        [win addSubview:g_secField];
        UIView* cv = g_secField.subviews.firstObject;
        if (cv) {
            [g_root removeFromSuperview];
            g_root.frame = win.bounds;
            [cv addSubview:g_root];
        } else {
            [g_secField removeFromSuperview];
            g_secField = nil;   // trick unavailable on this OS -> keep normal
        }
    } else if (!on && g_secField) {
        [g_root removeFromSuperview];
        win.rootViewController.view = g_root;
        [g_secField removeFromSuperview];
        g_secField = nil;
    }
}

// ---------------------------------------------------------------- panel UI
// kiss-parity: dark ImGui-style panel, "KISS ESP" header, xmark close that
// collapses the menu into a dynamic-island pill, 4 SF-Symbol tabs
// (eye=visuals, scope=aim, paintbrush=about, slider.horizontal.3=tools)

UIView* g_rootCanvas();   // defined at file end

static UIView* panelPage(UIView* p, int idx) {
    UIView* c = [[UIView alloc] initWithFrame:CGRectMake(0, 72, 300, 296)];
    c.tag = 200 + idx;
    c.hidden = (idx != 0);
    c.backgroundColor = UIColor.clearColor;
    [p addSubview:c];
    return c;
}

static void switchRow(UIView* c, NSString* name, int tag, int col, int row) {
    f32 x = 14 + col * 146;
    UILabel* l = [[UILabel alloc] initWithFrame:CGRectMake(x, 10 + row * 34, 76, 22)];
    l.text = name; l.textColor = UIColor.whiteColor; l.font = [UIFont systemFontOfSize:11];
    [c addSubview:l];
    UISwitch* sw = [[UISwitch alloc] initWithFrame:CGRectMake(x + 74, 6 + row * 34, 40, 24)];
    sw.transform = CGAffineTransformMakeScale(0.62, 0.62);
    sw.tag = tag;
    sw.on = g_sw.value(tag);
    [sw addTarget:g_rootCanvas() action:@selector(toggleSwitch:) forControlEvents:UIControlEventValueChanged];
    [c addSubview:sw];
}

static void buildPanel(ESPCanvasView* root) {
    UIView* p = [[UIView alloc] initWithFrame:CGRectMake(8, 54, 300, 372)];
    p.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.94];
    p.layer.cornerRadius = 14;
    p.layer.borderWidth = 1;
    p.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.08].CGColor;
    p.hidden = YES;
    root.panel = p; [root addSubview:p];

    // header
    UILabel* title = [[UILabel alloc] initWithFrame:CGRectMake(14, 8, 200, 22)];
    title.text = @"KISS ESP"; title.textColor = UIColor.whiteColor;
    title.font = [UIFont boldSystemFontOfSize:15];
    [p addSubview:title];

    UIButton* close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.frame = CGRectMake(260, 5, 30, 28);
    UIImage* xm = [UIImage systemImageNamed:@"xmark"];
    if (xm) [close setImage:xm forState:UIControlStateNormal];
    else [close setTitle:@"X" forState:UIControlStateNormal];
    close.tintColor = [UIColor colorWithWhite:1 alpha:0.85];
    [close addTarget:root action:@selector(closePanelTap) forControlEvents:UIControlEventTouchUpInside];
    [p addSubview:close];

    // tab bar: kiss icon set
    NSArray* tabs = @[@"eye", @"scope", @"paintbrush", @"slider.horizontal.3"];
    for (int i = 0; i < 4; ++i) {
        UIButton* tb = [UIButton buttonWithType:UIButtonTypeSystem];
        tb.frame = CGRectMake(8 + i * 73, 36, 70, 30);
        tb.tag = 100 + i;
        UIImage* im = [UIImage systemImageNamed:tabs[i]];
        if (im) [tb setImage:im forState:UIControlStateNormal];
        else [tb setTitle:@[@"VIS", @"AIM", @"SKIN", @"MISC"][i] forState:UIControlStateNormal];
        tb.tintColor = (i == 0) ? UIColor.systemGreenColor : [UIColor colorWithWhite:1 alpha:0.35];
        [tb addTarget:root action:@selector(tabChanged:) forControlEvents:UIControlEventTouchUpInside];
        [p addSubview:tb];
    }
    UIView* sep = [[UIView alloc] initWithFrame:CGRectMake(10, 70, 280, 1)];
    sep.backgroundColor = [UIColor colorWithWhite:1 alpha:0.10];
    [p addSubview:sep];

    // ---- page 0: eye (visual toggles)
    UIView* c0 = panelPage(p, 0);
    NSArray* vis = @[ @[@"Master", @0], @[@"ESP", @1], @[@"Radar", @3], @[@"Icons", @5],
                      @[@"Antenna", @6], @[@"LoS", @7], @[@"Armor", @10], @[@"Warn", @8],
                      @[@"Back", @9], @[@"AntiRec", @11] ];
    for (int i = 0; i < (int)vis.count; ++i) {
        NSArray* r = vis[i];
        switchRow(c0, r[0], [r[1] intValue], i % 2, i / 2);
    }

    // ---- page 1: scope (aim)
    UIView* c1 = panelPage(p, 1);
    switchRow(c1, @"Aim", 2, 0, 0);
    switchRow(c1, @"NoBot", 12, 1, 0);
    switchRow(c1, @"Safe", 4, 0, 1);

    UISegmentedControl* seg = [[UISegmentedControl alloc] initWithItems:@[@"Head", @"Neck", @"Chest"]];
    seg.frame = CGRectMake(14, 86, 272, 30);
    seg.selectedSegmentIndex = MAX(0, g_sw.lockPart);
    [seg addTarget:root action:@selector(lockPartChanged:) forControlEvents:UIControlEventValueChanged];
    [c1 addSubview:seg];

    UILabel* sl = [[UILabel alloc] initWithFrame:CGRectMake(14, 126, 80, 20)];
    sl.text = @"部位微调"; sl.textColor = [UIColor colorWithWhite:1 alpha:0.8];
    sl.font = [UIFont systemFontOfSize:11];
    [c1 addSubview:sl];
    UISlider* shift = [[UISlider alloc] initWithFrame:CGRectMake(96, 124, 148, 24)];
    shift.minimumValue = -0.5; shift.maximumValue = 0.5;
    shift.value = g_sw.lockShift;
    [shift addTarget:root action:@selector(lockShiftChanged:) forControlEvents:UIControlEventValueChanged];
    [c1 addSubview:shift];
    UILabel* shiftVal = [[UILabel alloc] initWithFrame:CGRectMake(248, 126, 40, 20)];
    shiftVal.tag = 778;
    shiftVal.text = [NSString stringWithFormat:@"%+.2f", g_sw.lockShift];
    shiftVal.textColor = [UIColor colorWithWhite:1 alpha:0.8];
    shiftVal.font = [UIFont systemFontOfSize:11];
    shiftVal.textAlignment = NSTextAlignmentRight;
    [c1 addSubview:shiftVal];

    UILabel* fl = [[UILabel alloc] initWithFrame:CGRectMake(14, 158, 70, 20)];
    fl.text = @"Aim FOV"; fl.textColor = [UIColor colorWithWhite:1 alpha:0.8];
    fl.font = [UIFont systemFontOfSize:11];
    [c1 addSubview:fl];
    UISlider* fov = [[UISlider alloc] initWithFrame:CGRectMake(96, 156, 192, 24)];
    fov.minimumValue = 0.5; fov.maximumValue = 2.0; fov.value = g_sw.fovMul;
    [fov addTarget:root action:@selector(fovChanged:) forControlEvents:UIControlEventValueChanged];
    [c1 addSubview:fov];

    // ---- page 2: tools (AutoScan / report / dump)
    UIView* c2 = panelPage(p, 2);
    UIButton* scan = [UIButton buttonWithType:UIButtonTypeSystem];
    scan.frame = CGRectMake(14, 12, 92, 30);
    scan.backgroundColor = [UIColor.systemBlueColor colorWithAlphaComponent:0.35];
    scan.layer.cornerRadius = 6;
    [scan setTitle:@"AutoScan" forState:UIControlStateNormal];
    scan.tintColor = UIColor.whiteColor;
    scan.titleLabel.font = [UIFont boldSystemFontOfSize:12];
    [scan addTarget:root action:@selector(autoScanTap:) forControlEvents:UIControlEventTouchUpInside];
    [c2 addSubview:scan];

    UILabel* status = [[UILabel alloc] initWithFrame:CGRectMake(114, 12, 172, 40)];
    status.tag = 777;
    status.textColor = [UIColor colorWithWhite:1 alpha:0.75];
    status.font = [UIFont systemFontOfSize:9];
    status.numberOfLines = 3;
    status.text = @"idle";
    [c2 addSubview:status];

    UIButton* rep = [UIButton buttonWithType:UIButtonTypeSystem];
    rep.frame = CGRectMake(14, 54, 92, 30);
    rep.backgroundColor = [UIColor.systemOrangeColor colorWithAlphaComponent:0.35];
    rep.layer.cornerRadius = 6;
    [rep setTitle:@"Help/Report" forState:UIControlStateNormal];
    rep.tintColor = UIColor.whiteColor;
    rep.titleLabel.font = [UIFont boldSystemFontOfSize:12];
    [rep addTarget:root action:@selector(helpReportTap:) forControlEvents:UIControlEventTouchUpInside];
    [c2 addSubview:rep];

    UIButton* dump = [UIButton buttonWithType:UIButtonTypeSystem];
    dump.frame = CGRectMake(114, 54, 92, 30);
    dump.backgroundColor = [UIColor.systemPurpleColor colorWithAlphaComponent:0.35];
    dump.layer.cornerRadius = 6;
    [dump setTitle:@"SigDump" forState:UIControlStateNormal];
    dump.tintColor = UIColor.whiteColor;
    dump.titleLabel.font = [UIFont boldSystemFontOfSize:12];
    [dump addTarget:root action:@selector(sigDumpTap:) forControlEvents:UIControlEventTouchUpInside];
    [c2 addSubview:dump];

    // ---- page 3: paintbrush (about)
    UIView* c3 = panelPage(p, 3);
    UILabel* about = [[UILabel alloc] initWithFrame:CGRectMake(14, 14, 272, 120)];
    about.numberOfLines = 0;
    about.textColor = [UIColor colorWithWhite:1 alpha:0.75];
    about.font = [UIFont systemFontOfSize:11];
    about.text = @"KISS ESP style UI\nbuild 1.0.0 - cross-process ESP\n\nhold ball = aim\ntap ball = open/close menu\ndrag ball = move\nclose (x) = collapse to island";
    [c3 addSubview:about];

    // island pill (collapsed menu)
    UIButton* pill = [UIButton buttonWithType:UIButtonTypeSystem];
    pill.frame = CGRectMake((root.bounds.size.width - 84) / 2, 10, 84, 24);
    [pill setTitle:@"KISS ESP" forState:UIControlStateNormal];
    pill.titleLabel.font = [UIFont boldSystemFontOfSize:10];
    pill.tintColor = UIColor.whiteColor;
    pill.backgroundColor = [UIColor colorWithWhite:0.1 alpha:0.92];
    pill.layer.cornerRadius = 12;
    pill.hidden = YES;
    [pill addTarget:root action:@selector(islandTap) forControlEvents:UIControlEventTouchUpInside];
    [root addSubview:pill];
    root.pill = pill;
}

@implementation ESPCanvasView (Actions)
- (void)toggleSwitch:(UISwitch*)s {
    switch (s.tag) {
        case 0: g_sw.master = s.on; break;
        case 1: g_sw.esp = s.on; break;
        case 2: g_sw.aim = s.on; break;
        case 3: g_sw.radar = s.on; break;
        case 4: g_sw.safeMode = s.on; break;
        case 5: g_sw.icons = s.on; break;
        case 6: g_sw.antenna = s.on; break;
        case 7: g_sw.losLine = s.on; break;
        case 8: g_sw.warning = s.on; break;
        case 9: g_sw.backEnemy = s.on; break;
        case 10: g_sw.armor = s.on; break;
        case 11: g_sw.antiRec = s.on; applyAntiRec(self.window, s.on); break;
        case 12: g_sw.noBotAim = s.on; break;
    }
}
- (void)lockPartChanged:(UISegmentedControl*)s {
    g_sw.lockPart = (int)s.selectedSegmentIndex; // 0=Head 1=Neck 2=Chest
    [[NSUserDefaults standardUserDefaults] setInteger:g_sw.lockPart forKey:@"id_lockPart"];
}
- (void)lockShiftChanged:(UISlider*)sl {
    g_sw.lockShift = (float)sl.value;
    UILabel* v = (UILabel*)[self viewWithTag:778];
    v.text = [NSString stringWithFormat:@"%+.2f", g_sw.lockShift];
    [[NSUserDefaults standardUserDefaults] setDouble:g_sw.lockShift forKey:@"id_lockShift"];
}
- (void)fovChanged:(UISlider*)s { g_sw.fovMul = s.value; }
- (void)gearTap {
    self.panel.hidden = !self.panel.hidden;
    if (!self.panel.hidden) self.pill.hidden = YES;
}
- (void)closePanelTap { self.panel.hidden = YES; self.pill.hidden = NO; }
- (void)islandTap     { self.pill.hidden = YES; self.panel.hidden = NO; }
- (void)tabChanged:(UIButton*)b {
    int sel = (int)b.tag - 100;
    for (int i = 0; i < 4; ++i) {
        UIButton* tb = (UIButton*)[self.panel viewWithTag:100 + i];
        tb.tintColor = (i == sel) ? UIColor.systemGreenColor : [UIColor colorWithWhite:1 alpha:0.35];
        UIView* pg = [self.panel viewWithTag:200 + i];
        pg.hidden = (i != sel);
    }
}
- (void)startTap {           // kiss-style: start button spawns the ball
    self.startBtn.hidden = YES;
    self.ball.hidden = NO;
    self.gear.hidden = NO;
}

- (void)autoScanTap:(UIButton*)b {
    if (autoScanBusy()) return;
    autoScanStart();
    b.userInteractionEnabled = NO;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        static int n = 0;
        if (n++ < 40) {
            UILabel* st = [self.panel viewWithTag:777];
            st.text = [autoScanStatusText() stringByReplacingOccurrencesOfString:@"AutoScan:\n" withString:@""];
            st.text = [st.text substringToIndex:MIN((NSInteger)180, (NSInteger)st.text.length)];
            if (autoScanBusy()) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), ^{ [self autoScanTap:b]; });
            } else {
                b.userInteractionEnabled = YES;
                st.text = autoScanLastOK() ? @"OK ✓" : @"partial";
            }
        } else b.userInteractionEnabled = YES;
    });
}

- (void)sigDumpTap:(UIButton*)b {
    requestSigDump();
    UILabel* st = [self.panel viewWithTag:777];
    st.text = @"dump written (Documents/dump.txt)";
    (void)b;
}

- (void)helpReportTap:(UIButton*)b {
    NSMutableString* r = [NSMutableString stringWithFormat:@"=== InjectorDemo report %@\n",
                          [NSDate date]];
    [r appendFormat:@"game pid %d base %016llx\n", g_gamePid, (unsigned long long)g_gameBase];
    [r appendFormat:@"autoscan: %@\n", autoScanStatusText()];
    [r appendFormat:@"frame: ready=%d ents=%d warns=%d\n", g_frame.ready, g_frame.entCount, g_frame.warnCount];
    NSArray* docs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    for (NSString* fn in @[@"autoscan.txt", @"dump.txt", @"watchdog.txt"]) {
        NSString* p = [docs[0] stringByAppendingPathComponent:fn];
        NSString* c = [NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:nil];
        [r appendFormat:@"\n--- %@ ---\n%@\n", fn, c ?: @"(none)"];
    }
    NSString* out = [docs[0] stringByAppendingPathComponent:@"report.txt"];
    [r writeToFile:out atomically:YES encoding:NSUTF8StringEncoding error:nil];

    UIAlertController* a = [UIAlertController alertControllerWithTitle:@"Report generated"
        message:[NSString stringWithFormat:@"Send this file:\n%@", out]
        preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    UIViewController* vc = self.window.rootViewController;
    [vc presentViewController:a animated:YES completion:nil];
    (void)b;
}
@end

// ---------------------------------------------------------------- boot

void startOverlay(UIWindow* win) {
    if (g_root) return;
    CGRect sc = win.bounds;

    g_root = [[ESPCanvasView alloc] initWithFrame:sc];
    g_root.backgroundColor = UIColor.clearColor;
    g_root.opaque = NO;
    win.rootViewController = [[UIViewController alloc] init];
    win.rootViewController.view = g_root;

    // floating ball
    CGFloat bx = 40, by = sc.size.height * 0.35;
    NSUserDefaults* ud = NSUserDefaults.standardUserDefaults;
    if ([ud objectForKey:@"id_ball_x"]) {
        bx = (CGFloat)[ud doubleForKey:@"id_ball_x"];
        by = (CGFloat)[ud doubleForKey:@"id_ball_y"];
        // slide-over <-> fullscreen resizes: clamp saved pos into current bounds
        bx = MIN(MAX(bx, 30), sc.size.width  - 30);
        by = MIN(MAX(by, 60), sc.size.height - 30);
    }
    BallView* ball = [[BallView alloc] initWithFrame:CGRectMake(0, 0, 52, 52)];
    ball.center = CGPointMake(bx, by);
    ball.backgroundColor = [UIColor colorWithWhite:0.05 alpha:0.9];
    ball.layer.cornerRadius = 26;
    ball.layer.masksToBounds = YES;
    UIImageView* biv = [[UIImageView alloc] initWithFrame:ball.bounds];
    biv.image = [UIImage imageNamed:@"ball"];   // kiss "91" logo asset
    biv.contentMode = UIViewContentModeScaleAspectFill;
    biv.userInteractionEnabled = NO;
    [ball addSubview:biv];
    UIPanGestureRecognizer* pan = [[UIPanGestureRecognizer alloc] initWithTarget:ball action:@selector(dragWith:)];
    [ball addGestureRecognizer:pan];
    [g_root addSubview:ball];
    g_root.ball = ball;
    ball.hidden = YES; // appears after Start

    // gear button
    UIButton* gear = [UIButton buttonWithType:UIButtonTypeSystem];
    gear.frame = CGRectMake(12, 24, 34, 34);
    gear.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.55];
    gear.layer.cornerRadius = 17;
    [gear setTitle:@"I" forState:UIControlStateNormal];
    gear.tintColor = UIColor.whiteColor;
    [gear addTarget:g_root action:@selector(gearTap) forControlEvents:UIControlEventTouchUpInside];
    g_root.gear = gear;
    [g_root addSubview:gear];
    gear.hidden = YES; // appears after Start

    // kiss-style start button, center screen
    UIButton* startBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    startBtn.frame = CGRectMake(sc.size.width/2 - 90, sc.size.height/2 - 30, 180, 60);
    startBtn.backgroundColor = [UIColor.systemGreenColor colorWithAlphaComponent:0.85];
    startBtn.layer.cornerRadius = 14;
    [startBtn setTitle:@"启 动" forState:UIControlStateNormal];
    [startBtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    startBtn.titleLabel.font = [UIFont boldSystemFontOfSize:24];
    [startBtn addTarget:g_root action:@selector(startTap) forControlEvents:UIControlEventTouchUpInside];
    g_root.startBtn = startBtn;
    [g_root addSubview:startBtn];

    NSUserDefaults* ud2 = NSUserDefaults.standardUserDefaults;
    if ([ud2 objectForKey:@"id_lockPart"]) g_sw.lockPart = (int)[ud2 integerForKey:@"id_lockPart"];
    if ([ud2 objectForKey:@"id_lockShift"]) g_sw.lockShift = (float)[ud2 doubleForKey:@"id_lockShift"];
    buildPanel(g_root);
    g_root.panel.hidden = YES;
}

void requestSigDump() { doSigDump(); }

UIView* g_rootCanvas() { return g_root; }
