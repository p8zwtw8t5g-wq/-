#import "Overlay.h"
#import "Config.h"
#import "Aim.h"
#import "TouchMon.h"
#import "AutoScan.h"
#import "SigScan.h"
#import "StrObf.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

Frame g_frame;
Switches g_sw;

void buildFrame();          // Tweak.mm: read world -> g_frame
WeaponProfile* currentWeaponProfile(); // Tweak.mm

// trigger state lives in TouchMon (g_aimTrigger) — global touch monitor

static float randf1() { return (float)arc4random() / (float)UINT32_MAX * 2.f - 1.f; }

// ---------------------------------------------------------------- ESP view

@class BallView;

@interface ESPRootView : UIView
@property (nonatomic, strong) UIButton* gear;
@property (nonatomic, strong) UIView* panel;
@property (nonatomic, strong) BallView* ball;
@property (nonatomic, assign) CGRect triggerZone;
@end

// AssistiveTouch-style floating ball: hold = aim trigger, tap = panel,
// drag = reposition (position persisted). While panel is open the ball drags.
@interface BallView : UIView
@property (nonatomic, assign) double downT;
@property (nonatomic, assign) CGPoint downP;
@end

@implementation BallView
- (void)touchesBegan:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {
    UITouch* touch = t.anyObject;
    g_ballTouchId = (uintptr_t)touch;
    g_ballPressed = YES;
    self.downT = [NSDate date].timeIntervalSince1970;
    self.downP = self.center;
    self.backgroundColor = [UIColor.systemRedColor colorWithAlphaComponent:0.55];
}
- (void)touchesEnded:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {
    g_ballPressed = NO; g_ballTouchId = 0;
    self.backgroundColor = [UIColor.whiteColor colorWithAlphaComponent:0.30];
    double dt = [NSDate date].timeIntervalSince1970 - self.downT;
    CGPoint moved = CGPointMake(self.center.x - self.downP.x, self.center.y - self.downP.y);
    if (dt < 0.25 && hypot(moved.x, moved.y) < 12) {
        // tap -> toggle panel
        ESPRootView* root = (ESPRootView*)self.superview;
        root.panel.hidden = !root.panel.hidden;
    }
}
- (void)touchesCancelled:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {
    g_ballPressed = NO; g_ballTouchId = 0;
    self.backgroundColor = [UIColor.whiteColor colorWithAlphaComponent:0.30];
}
- (void)dragWith:(UIPanGestureRecognizer*)g {
    ESPRootView* root = (ESPRootView*)self.superview;
    if (root.panel.hidden) return; // drag only while panel open
    CGPoint tr = [g translationInView:self.superview];
    if (g.state == UIGestureRecognizerStateChanged) {
        CGRect sc = self.superview.bounds;
        CGFloat nx = MIN(MAX(self.center.x + tr.x, 30), sc.size.width - 30);
        CGFloat ny = MIN(MAX(self.center.y + tr.y, 60), sc.size.height - 30);
        self.center = CGPointMake(nx, ny);
        [g setTranslation:CGPointZero inView:self.superview];
    }
    if (g.state == UIGestureRecognizerStateEnded) {
        [[NSUserDefaults standardUserDefaults] setDouble:self.center.x forKey:@"id_ball_x"];
        [[NSUserDefaults standardUserDefaults] setDouble:self.center.y forKey:@"id_ball_y"];
    }
}
@end

@implementation ESPRootView

- (UIView*)hitTest:(CGPoint)p withEvent:(UIEvent*)e {
    if (!g_sw.master) return nil;
    // gear + panel are ordinary subviews: UIKit resolves them before this,
    // so only the leftover area needs a passthrough decision here.
    if (CGRectContainsPoint(self.bounds, p)) {
        if (!self.panel.hidden &&
            CGRectContainsPoint(self.panel.bounds, [self convertPoint:p toView:self.panel]))
            return self.panel;
        if (CGRectContainsPoint(self.triggerZone, p)) return self; // consume: aim trigger
        return nil; // pass everything else through to the game
    }
    return nil;
}

// trigger is evaluated globally in TouchMon; these consume the zone touch
- (void)touchesBegan:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {}
- (void)touchesEnded:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {}
- (void)touchesCancelled:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e {}

- (void)drawRect:(CGRect)rect {
    CGContextRef c = UIGraphicsGetCurrentContext();
    CGContextClearRect(c, rect);
    if (!g_sw.master || !g_sw.esp) {
        if (g_aimTrigger) [self drawTriggerHint:c];
        return;
    }
    Frame& f = g_frame;
    if (!f.ready) return;

    // dead / spectating: radar only, dimmed, nothing else leaks
    if (f.localDead) { [self drawRadar:c dim:YES]; return; }

    f32 cx = (f32)f.screenW * 0.5f, cy = (f32)f.screenH * 0.5f;

    // crosshair
    CGContextSetStrokeColorWithColor(c, [UIColor.systemGreenColor colorWithAlphaComponent:0.7].CGColor);
    CGContextSetLineWidth(c, 1.f);
    CGContextMoveToPoint(c, cx - 8, cy); CGContextAddLineToPoint(c, cx + 8, cy);
    CGContextMoveToPoint(c, cx, cy - 8); CGContextAddLineToPoint(c, cx, cy + 8);
    CGContextStrokePath(c);

    // radar minimap (top center)
    if (g_sw.radar) [self drawRadar:c dim:NO];

    // aim fov circle
    WeaponProfile* wp = currentWeaponProfile();
    f32 fovR = wp->fov * Config::fovGlobalMul * g_sw.fovMul;
    CGContextSetStrokeColorWithColor(c, [UIColor.systemYellowColor colorWithAlphaComponent:0.25].CGColor);
    CGContextStrokeEllipseInRect(c, CGRectMake(cx - fovR, cy - fovR, fovR * 2, fovR * 2));

    for (int i = 0; i < f.entCount; ++i) {
        Entity& e = f.ents[i];
        if (!e.used || !e.alive) continue;
        bool friendly = (f.localTeam >= 0 && e.team == f.localTeam && e.team != 0);
        UIColor* col = friendly ? [UIColor.systemBlueColor colorWithAlphaComponent:0.9]
                                : (e.visible ? [UIColor.systemRedColor colorWithAlphaComponent:0.95]
                                             : [UIColor.systemOrangeColor colorWithAlphaComponent:0.75]);

        f32 bx, by, hx, hy, ox, oy;
        if (!w2sFrame(f, e.origin, ox, oy)) continue;
        if (!w2sFrame(f, e.head, hx, hy)) continue;
        // estimate box height: head->origin span, width = 0.45 * height
        f32 h = fabsf(oy - hy) * 2.15f;
        bx = hx - h * 0.22f; by = hy - h * 0.06f;
        f32 bw = h * 0.45f;

        CGContextSetStrokeColorWithColor(c, col.CGColor);
        CGContextSetLineWidth(c, 1.5f);
        // corner-box
        f32 cl = bw * 0.25f;
        CGContextMoveToPoint(c, bx, by + cl);        CGContextAddLineToPoint(c, bx, by);
        CGContextAddLineToPoint(c, bx + cl, by);
        CGContextMoveToPoint(c, bx + bw - cl, by);   CGContextAddLineToPoint(c, bx + bw, by);
        CGContextAddLineToPoint(c, bx + bw, by + cl);
        CGContextMoveToPoint(c, bx + bw, by + h - cl); CGContextAddLineToPoint(c, bx + bw, by + h);
        CGContextAddLineToPoint(c, bx + bw - cl, by + h);
        CGContextMoveToPoint(c, bx + cl, by + h);    CGContextAddLineToPoint(c, bx, by + h);
        CGContextAddLineToPoint(c, bx, by + h - cl);
        CGContextStrokePath(c);

        // skeleton
        if (e.boneOk) [self drawSkeleton:c ent:e color:col];

        // head dot
        CGContextSetFillColorWithColor(c, col.CGColor);
        CGContextFillEllipseInRect(c, CGRectMake(hx - 2, hy - 2, 4, 4));

        // health bar
        if (e.hp >= 0.f) {
            f32 frac = e.hp / 100.f; if (frac > 1) frac = 1;
            CGContextSetFillColorWithColor(c, [UIColor.blackColor colorWithAlphaComponent:0.6].CGColor);
            CGContextFillRect(c, CGRectMake(bx - 6, by, 3, h));
            CGContextSetFillColorWithColor(c, [UIColor.systemGreenColor colorWithAlphaComponent:0.9].CGColor);
            CGContextFillRect(c, CGRectMake(bx - 6, by + h * (1 - frac), 3, h * frac));
        }

        // dist text
        if (e.dist > 0.1f) {
            NSString* t = [NSString stringWithFormat:@"%.0fm", e.dist];
            [t drawAtPoint:CGPointMake(bx + bw + 4, by)
            withAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:10],
                             NSForegroundColorAttributeName: col}];
        }
    }
    if (g_aimTrigger) [self drawTriggerHint:c];
}

- (void)drawSkeleton:(CGContextRef)c ent:(Entity&)e color:(UIColor*)col {
    extern NSString* g_skeletonPairs; // "i-j,i-j,..." from config
    if (g_skeletonPairs.length == 0) return;
    CGContextSetStrokeColorWithColor(c, col.CGColor);
    CGContextSetLineWidth(c, 1.f);
    for (NSString* pair in [g_skeletonPairs componentsSeparatedByString:@","]) {
        NSArray* ij = [pair componentsSeparatedByString:@"-"];
        if (ij.count != 2) continue;
        int a = [(NSString*)ij[0] intValue], b = [(NSString*)ij[1] intValue];
        if (a < 0 || b < 0 || a >= e.boneCount || b >= e.boneCount) continue;
        f32 ax, ay, bxx, byy;
        if (!w2sFrame(g_frame, e.bones[a], ax, ay)) continue;
        if (!w2sFrame(g_frame, e.bones[b], bxx, byy)) continue;
        CGContextMoveToPoint(c, ax, ay);
        CGContextAddLineToPoint(c, bxx, byy);
    }
    CGContextStrokePath(c);
}

- (void)drawTriggerHint:(CGContextRef)c {
    CGContextSetStrokeColorWithColor(c, [UIColor.systemRedColor colorWithAlphaComponent:0.5].CGColor);
    CGContextSetLineWidth(c, 2.f);
    CGRect z = self.triggerZone;
    CGContextStrokeRect(c, CGRectInset(z, 2, 2));
}

// radar minimap: rotated by camera yaw, up = facing direction
- (void)drawRadar:(CGContextRef)c dim:(BOOL)dim {
    Frame& f = g_frame;
    f32 R = 60.f, alpha = dim ? 0.25f : 0.85f;
    CGPoint cc = CGPointMake((f32)f.screenW * 0.5f, 84.f);

    // dial
    CGContextSetFillColorWithColor(c, [UIColor.blackColor colorWithAlphaComponent:0.35 * alpha].CGColor);
    CGContextFillEllipseInRect(c, CGRectMake(cc.x - R, cc.y - R, R * 2, R * 2));
    CGContextSetStrokeColorWithColor(c, [UIColor.whiteColor colorWithAlphaComponent:0.3 * alpha].CGColor);
    CGContextSetLineWidth(c, 1.f);
    CGContextStrokeEllipseInRect(c, CGRectMake(cc.x - R, cc.y - R, R * 2, R * 2));
    CGContextMoveToPoint(c, cc.x - R, cc.y); CGContextAddLineToPoint(c, cc.x + R, cc.y);
    CGContextMoveToPoint(c, cc.x, cc.y - R); CGContextAddLineToPoint(c, cc.x, cc.y + R);
    CGContextStrokePath(c);

    // view cone (fov wedge, up = facing)
    CGContextSetFillColorWithColor(c, [UIColor.whiteColor colorWithAlphaComponent:0.10 * alpha].CGColor);
    CGContextMoveToPoint(c, cc.x, cc.y);
    CGContextAddArc(c, cc.x, cc.y, R * 0.85f, -(f32)M_PI_2 - 0.6f, -(f32)M_PI_2 + 0.6f, 0);
    CGContextClosePath(c);
    CGContextFillPath(c);

    // camera basis projected on the horizontal plane
    const f32 d = (f32)M_PI / 180.f;
    f32 yaw = f.camRot.yaw * d, sy = sinf(yaw), cyy = cosf(yaw);
    f32 scale = R / Config::radarRange;

    for (int i = 0; i < f.entCount; ++i) {
        Entity& e = f.ents[i];
        if (!e.used || !e.alive) continue;
        bool friendly = (f.localTeam >= 0 && e.team == f.localTeam && e.team != 0);
        // world -> radar: rotate world offset by -yaw
        f32 wx = e.origin.x - f.camLoc.x, wy = e.origin.y - f.camLoc.y;
        f32 rx =  wx * cyy + wy * sy;   // right
        f32 ry = -wx * sy  + wy * cyy;  // forward
        f32 px = cc.x + rx * scale;
        f32 py = cc.y - ry * scale;
        f32 dd = hypotf(px - cc.x, py - cc.y);
        if (dd > R - 3) { // clamp to rim (out of range marker)
            px = cc.x + (px - cc.x) / dd * (R - 3);
            py = cc.y + (py - cc.y) / dd * (R - 3);
        }
        UIColor* col = friendly ? [UIColor.systemBlueColor colorWithAlphaComponent:alpha]
                     : (e.visible ? [UIColor.systemRedColor colorWithAlphaComponent:alpha]
                                  : [UIColor.systemOrangeColor colorWithAlphaComponent:0.7f * alpha]);
        CGContextSetFillColorWithColor(c, col.CGColor);
        CGContextFillEllipseInRect(c, CGRectMake(px - 3, py - 3, 6, 6));
    }

    // self dot
    CGContextSetFillColorWithColor(c, [UIColor.systemGreenColor colorWithAlphaComponent:alpha].CGColor);
    CGContextFillEllipseInRect(c, CGRectMake(cc.x - 2.5, cc.y - 2.5, 5, 5));
}

@end

// ---------------------------------------------------------------- window

@implementation ESPWindow
- (BOOL)pointInside:(CGPoint)p withEvent:(UIEvent*)e {
    // window accepts touches only through the root view's own logic
    return [super pointInside:p withEvent:e];
}
@end

@interface PanelHost : NSObject
@end
@implementation PanelHost
@end

static ESPRootView* g_root = nil;
static ESPWindow* g_win = nil;

void requestSigDump() {
    extern void doSigDump();
    doSigDump();
}

// ---------------------------------------------------------------- panel UI

static UISwitch* mkSwitch(id t, SEL s, BOOL on) {
    UISwitch* sw = [[UISwitch alloc] init];
    sw.on = on; [sw addTarget:t action:s forControlEvents:UIControlEventValueChanged];
    return sw;
}

static void buildPanel(ESPRootView* root) {
    UIView* p = [[UIView alloc] initWithFrame:CGRectMake(12, 60, 220, 240)];
    p.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.78];
    p.layer.cornerRadius = 12;
    p.hidden = YES;
    root.panel = p; [root addSubview:p];

    UILabel* title = [[UILabel alloc] initWithFrame:CGRectMake(14, 8, 192, 20)];
    title.text = @"Injector demo"; title.textColor = UIColor.whiteColor;
    title.font = [UIFont boldSystemFontOfSize:13];
    [p addSubview:title];

    NSArray* labels = @[@"Master", @"ESP", @"Aim", @"SafeMode", @"Radar"];
    for (int i = 0; i < 5; ++i) {
        UILabel* l = [[UILabel alloc] initWithFrame:CGRectMake(14, 38 + i * 34, 90, 24)];
        l.text = labels[i]; l.textColor = UIColor.whiteColor; l.font = [UIFont systemFontOfSize:12];
        [p addSubview:l];
        UISwitch* sw = [[UISwitch alloc] initWithFrame:CGRectMake(150, 34 + i * 34, 51, 31)];
        sw.transform = CGAffineTransformMakeScale(0.7, 0.7);
        sw.on = i == 0 ? g_sw.master : (i == 1 ? g_sw.esp : (i == 2 ? g_sw.aim : (i == 3 ? g_sw.safeMode : g_sw.radar)));
        switch (i) {
            case 0: [sw addTarget:root action:@selector(tglMaster:) forControlEvents:UIControlEventValueChanged]; break;
            case 1: [sw addTarget:root action:@selector(tglEsp:) forControlEvents:UIControlEventValueChanged]; break;
            case 2: [sw addTarget:root action:@selector(tglAim:) forControlEvents:UIControlEventValueChanged]; break;
            case 3: [sw addTarget:root action:@selector(tglSafe:) forControlEvents:UIControlEventValueChanged]; break;
            case 4: [sw addTarget:root action:@selector(tglRadar:) forControlEvents:UIControlEventValueChanged]; break;
        }
        [p addSubview:sw];
    }

    UISegmentedControl* seg = [[UISegmentedControl alloc] initWithItems:@[@"Head", @"Neck", @"Chest"]];
    seg.frame = CGRectMake(14, 214, 192, 30);
    seg.selectedSegmentIndex = 0;
    [seg addTarget:root action:@selector(lockPartChanged:) forControlEvents:UIControlEventValueChanged];
    [p addSubview:seg];

    UISlider* fov = [[UISlider alloc] initWithFrame:CGRectMake(14, 248, 192, 24)];
    fov.minimumValue = 0.5; fov.maximumValue = 2.0; fov.value = 1.0;
    [fov addTarget:root action:@selector(fovChanged:) forControlEvents:UIControlEventValueChanged];
    [p addSubview:fov];

    // AutoScan: one-tap offset auto-discovery
    UIButton* scan = [UIButton buttonWithType:UIButtonTypeSystem];
    scan.frame = CGRectMake(14, 278, 92, 30);
    scan.backgroundColor = [UIColor.systemBlueColor colorWithAlphaComponent:0.35];
    scan.layer.cornerRadius = 6;
    [scan setTitle:@"AutoScan" forState:UIControlStateNormal];
    scan.tintColor = UIColor.whiteColor;
    scan.titleLabel.font = [UIFont boldSystemFontOfSize:12];
    [scan addTarget:root action:@selector(autoScanTap:) forControlEvents:UIControlEventTouchUpInside];
    [p addSubview:scan];

    UILabel* status = [[UILabel alloc] initWithFrame:CGRectMake(112, 278, 94, 30)];
    status.tag = 777;
    status.textColor = [UIColor colorWithWhite:1 alpha:0.75];
    status.font = [UIFont systemFontOfSize:9];
    status.numberOfLines = 3;
    status.text = @"idle";
    [p addSubview:status];

    // one-tap support report: writes everything needed for remote diagnosis
    UIButton* rep = [UIButton buttonWithType:UIButtonTypeSystem];
    rep.frame = CGRectMake(14, 312, 92, 30);
    rep.backgroundColor = [UIColor.systemOrangeColor colorWithAlphaComponent:0.35];
    rep.layer.cornerRadius = 6;
    [rep setTitle:@"Help/Report" forState:UIControlStateNormal];
    rep.tintColor = UIColor.whiteColor;
    rep.titleLabel.font = [UIFont boldSystemFontOfSize:12];
    [rep addTarget:root action:@selector(helpReportTap:) forControlEvents:UIControlEventTouchUpInside];
    [p addSubview:rep];

    // taller panel for the new rows
    CGRect pf = p.frame; pf.size.height = 350; p.frame = pf;
}

@implementation ESPRootView (Actions2)
- (void)tglRadar:(UISwitch*)s { g_sw.radar = s.on; }
@end

@implementation ESPRootView (AutoScan)
- (void)autoScanTap:(UIButton*)b {
    if (autoScanBusy()) return;
    autoScanStart();
    b.userInteractionEnabled = NO;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        static int n = 0;
        if (n++ < 20) { // poll status
            UILabel* st = [self.panel viewWithTag:777];
            st.text = [autoScanStatusText() stringByReplacingOccurrencesOfString:@"AutoScan:\n" withString:@""];
            st.text = [st.text substringToIndex:MIN((NSInteger)180, (NSInteger)st.text.length)];
            if (autoScanBusy()) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), ^{ [self autoScanTap:b]; });
            } else {
                b.userInteractionEnabled = YES;
                st.text = autoScanLastOK() ? @"OK ✓" : @"partial";
            }
        } else b.userInteractionEnabled = YES;
    });
}
- (void)helpReportTap:(UIButton*)b {
    NSMutableString* r = [NSMutableString stringWithFormat:@"=== InjectorDemo report %@\n",
                          [NSDate date]];
    [r appendFormat:@"autoscan: %@\n", autoScanStatusText()];
    [r appendFormat:@"frame: ready=%d ents=%d\n", g_frame.ready, g_frame.entCount];
    for (NSString* fn in @[@"autoscan.txt", @"dump.txt", @"watchdog.txt"]) {
        NSString* p = [@"/var/jb/share/InjectorDemo/" stringByAppendingPathComponent:fn];
        NSString* c = [NSString stringWithContentsOfFile:p encoding:NSUTF8StringEncoding error:nil];
        [r appendFormat:@"\n--- %@ ---\n%@\n", fn, c ?: @"(none)"];
    }
    NSString* out = @"/var/jb/share/InjectorDemo/report.txt";
    [r writeToFile:out atomically:YES encoding:NSUTF8StringEncoding error:nil];

    UIAlertController* a = [UIAlertController alertControllerWithTitle:@"Report generated"
        message:[NSString stringWithFormat:@"Send this file:\n%@", out]
        preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    UIViewController* vc = self.window.rootViewController;
    [vc presentViewController:a animated:YES completion:nil];
}
@end

@implementation ESPRootView (Actions)
- (void)tglMaster:(UISwitch*)s { g_sw.master = s.on; }
- (void)tglEsp:(UISwitch*)s    { g_sw.esp = s.on; }
- (void)tglAim:(UISwitch*)s    { g_sw.aim = s.on; }
- (void)tglSafe:(UISwitch*)s   { g_sw.safeMode = s.on; }
- (void)lockPartChanged:(UISegmentedControl*)s {
    // seg 0/1/2 sets explicit part; long-press resets to weapon-profile default
    g_sw.lockPart = (int)s.selectedSegmentIndex;
}
- (void)fovChanged:(UISlider*)s { g_sw.fovMul = s.value; }
@end

// ---------------------------------------------------------------- tick

@interface TickHost : NSObject
@property CADisplayLink* dl;
@end
@implementation TickHost
- (void)tick {
    static BOOL busy = NO;
    if (busy) return; busy = YES;
    @try {
        touchMonEval();
        buildFrame();
        aimFrame();
        [g_root setNeedsDisplay];
    } @catch (...) {}
    busy = NO;
}
@end

void startOverlay() {
    if (g_win) return;
    CGRect sc = UIScreen.mainScreen.bounds;
    g_win = [[ESPWindow alloc] initWithFrame:sc];
    g_win.windowLevel = UIWindowLevelAlert + 1000.f;
    g_win.hidden = NO;
    g_win.backgroundColor = UIColor.clearColor;

    g_root = [[ESPRootView alloc] initWithFrame:sc];
    g_root.backgroundColor = UIColor.clearColor;
    g_root.opaque = NO;
    g_root.userInteractionEnabled = YES;
    g_win.rootViewController.view = g_win.rootViewController.view; // noop guard
    UIViewController* vc = [[UIViewController alloc] init];
    g_win.rootViewController = vc;
    vc.view = g_root;

    g_root.triggerZone = CGRectMake(sc.size.width * 0.70, sc.size.height * 0.55,
                                    sc.size.width * 0.30, sc.size.height * 0.45);

    // floating ball (AssistiveTouch style): hold = trigger, tap = panel
    CGFloat bx = 40, by = sc.size.height * 0.35;
    NSUserDefaults* ud = NSUserDefaults.standardUserDefaults;
    if ([ud objectForKey:@"id_ball_x"]) { bx = (CGFloat)[ud doubleForKey:@"id_ball_x"]; by = (CGFloat)[ud doubleForKey:@"id_ball_y"]; }
    BallView* ball = [[BallView alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
    ball.center = CGPointMake(bx, by);
    ball.backgroundColor = [UIColor.whiteColor colorWithAlphaComponent:0.30];
    ball.layer.cornerRadius = 22;
    ball.layer.borderWidth = 1;
    ball.layer.borderColor = [UIColor.whiteColor colorWithAlphaComponent:0.5].CGColor;
    ball.userInteractionEnabled = YES;
    UIPanGestureRecognizer* pan = [[UIPanGestureRecognizer alloc] initWithTarget:ball action:@selector(dragWith:)];
    [ball addGestureRecognizer:pan];
    g_root.ball = ball;
    [g_root addSubview:ball];

    // trigger modes from config: "ball,zone,second" (default ball+second)
    int modes = TRIG_BALL | TRIG_SECOND;
    if (NSDictionary* root = [NSDictionary dictionaryWithContentsOfFile:@"/var/jb/share/InjectorDemo/config.plist"]) {
        NSString* tm = root[@"triggerMode"];
        if (tm.length) {
            modes = 0;
            if ([tm rangeOfString:@"ball"].location   != NSNotFound) modes |= TRIG_BALL;
            if ([tm rangeOfString:@"zone"].location   != NSNotFound) modes |= TRIG_ZONE;
            if ([tm rangeOfString:@"second"].location != NSNotFound) modes |= TRIG_SECOND;
        }
    }
    touchMonSetModes(modes);
    touchMonSetZone(g_root.triggerZone);


    UIButton* gear = [UIButton buttonWithType:UIButtonTypeSystem];
    gear.frame = CGRectMake(12, 24, 34, 34);
    gear.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.55];
    gear.layer.cornerRadius = 17;
    [gear setTitle:@"I" forState:UIControlStateNormal];
    gear.tintColor = UIColor.whiteColor;
    [gear addTarget:g_root action:@selector(gearTap) forControlEvents:UIControlEventTouchUpInside];
    g_root.gear = gear;
    [g_root addSubview:gear];

    buildPanel(g_root);

    TickHost* th = [TickHost new];
    th.dl = [CADisplayLink displayLinkWithTarget:th selector:@selector(tick)];
    th.dl.preferredFramesPerSecond = 120; // ProMotion on the 2021 iPad Pro
    [th.dl addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];
}

@implementation ESPRootView (Gear)
- (void)gearTap { self.panel.hidden = !self.panel.hidden; }
@end
