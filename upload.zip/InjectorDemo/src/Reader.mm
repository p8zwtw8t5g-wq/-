#import "KRW.h"
#import "Config.h"
#import "Overlay.h"
#import "Aim.h"
#import "SigScan.h"
#import "AutoScan.h"
#import "StrObf.h"
#import "GameNames.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <mach/mach.h>
#import <stdio.h>

// remote-reading port of the original in-process reader: every access goes
// through KRW's rd/rdv over the game's task port.

Offsets OFF;

NSString* g_skeletonPairs = @"";

uintptr_t g_localPC = 0;

// persistent per-pawn tracker: render-freshness + velocity estimation
struct Tracker {
    uintptr_t pawn;
    f32 lastRenderPrev;
    f64 lastSeenT;
    FVec prevPos;
    f64 prevPosT;
};
static Tracker g_track[64];
static Tracker* trackFor(uintptr_t pawn) {
    for (auto& t : g_track) if (t.pawn == pawn) return &t;
    for (auto& t : g_track) if (!t.pawn) { t = {}; t.pawn = pawn; return &t; }
    static int rr = 0; Tracker& t = g_track[rr++ & 63]; t = {}; t.pawn = pawn; return &t;
}

WeaponProfile* g_curWeapon = nil;
WeaponProfile* currentWeaponProfile() { return g_curWeapon ? g_curWeapon : &Config::def; }

static NSString* docPath(NSString* fn) {
    return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0]
            stringByAppendingPathComponent:fn];
}

// ------------------------------------------------------------ FName decode

NSString* fNameToString(i32 index) {
    if (!SIG.gnames || index < 0) return nil;
    u32 stride = OFF.NameStride ? OFF.NameStride : 2;
    u32 blockIdx = (u32)index >> 16;
    u32 off16    = (u32)index & 0xFFFF;
    u64 block = rdv<u64>(SIG.gnames + 8 + (u64)blockIdx * 8);
    if (!block) return nil;
    u64 entry = block + (u64)off16 * stride;
    u16 header = rdv<u16>(entry);
    u32 len = header >> OFF.NameLenShift;
    if (len <= 0 || len > 128) return nil;
    bool wide = header & 1;
    char buf[256];
    if (wide) {
        u64 src = entry + 2;
        u16 wbuf[128]; rd(src, wbuf, len * 2);
        for (u32 i = 0; i < len && i < 128; ++i) buf[i] = (char)wbuf[i];
        buf[len < 128 ? len : 127] = 0;
    } else {
        rd(entry + 2, buf, len);
        buf[len < 255 ? len : 255] = 0;
    }
    if (OFF.NameXorKey) {
        u32 k = OFF.NameXorKey;
        for (u32 i = 0; buf[i]; ++i) buf[i] ^= (char)(k + i);
    }
    return [NSString stringWithUTF8String:buf];
}

// ------------------------------------------------------------ bone decrypt

static FVec decryptBonePos(const u8* raw, int boneIdx) {
    switch (Config::decryptMode) {
    case 1: {
        if (!SIG.decKey) { FVec v; memcpy(&v, raw + 0x10, 12); return v; }
        u32 k = rdv<u32>(SIG.decKey + ((u32)boneIdx * 4 & 0xFF));
        FVec v; memcpy(&v, raw + 0x10, 12);
        u32* p = (u32*)&v;
        p[0] ^= k;
        p[1] ^= (k << 7) | (k >> 25);
        p[2] ^= (k << 13) | (k >> 19);
        return v;
    }
    case 2: {
        struct Packed { i16 qx, qy, qz, px, py, pz; } pk;
        memcpy(&pk, raw, sizeof(Packed));
        FVec pos = { pk.px * 0.1f, pk.py * 0.1f, pk.pz * 0.1f };
        return pos;
    }
    default: {
        FVec v; memcpy(&v, raw + 0x10, 12);
        return v;
    }
    }
}

static FQuat decryptBoneQuat(const u8* raw, int boneIdx) {
    switch (Config::decryptMode) {
    case 2: {
        struct Packed { i16 qx, qy, qz, px, py, pz; } pk;
        memcpy(&pk, raw, sizeof(Packed));
        FVec qn = { pk.qx / 32767.f, pk.qy / 32767.f, pk.qz / 32767.f };
        f32 w2 = 1.f - qn.x*qn.x - qn.y*qn.y - qn.z*qn.z;
        return { qn.x, qn.y, qn.z, w2 > 0 ? sqrtf(w2) : 0.f };
    }
    case 1: {
        FQuat q; memcpy(&q, raw, 16);
        if (SIG.decKey) {
            u32 k = rdv<u32>(SIG.decKey + ((u32)(boneIdx + 97) * 4 & 0xFF));
            u32* p = (u32*)&q;
            p[0] ^= k; p[1] ^= (k << 11) | (k >> 21);
            p[2] ^= (k << 17) | (k >> 15); p[3] ^= (k << 3) | (k >> 29);
        }
        return q;
    }
    default: { FQuat q; memcpy(&q, raw, 16); return q; }
    }
}

static FQuat quatConj(const FQuat& q) { return { -q.x, -q.y, -q.z, q.w }; }
static FVec quatRot(const FQuat& q, const FVec& v) {
    (void)quatConj;
    FVec u = { q.x, q.y, q.z };
    f32 uv = u.x*v.x + u.y*v.y + u.z*v.z;
    f32 uu = u.x*u.x + u.y*u.y + u.z*u.z;
    f32 w2 = q.w * q.w;
    FVec t = { u.y*v.z - u.z*v.y, u.z*v.x - u.x*v.z, u.x*v.y - u.y*v.x };
    return {
        2*w2*v.x + 2*uv*u.x + 2*(uu - w2)*t.x,
        2*w2*v.y + 2*uv*u.y + 2*(uu - w2)*t.y,
        2*w2*v.z + 2*uv*u.z + 2*(uu - w2)*t.z,
    };
}

// ------------------------------------------------------------ weapon name

static NSString* weaponNameFor(uintptr_t pawn) {
    if (!OFF.Weapon) return nil;
    u64 wpn = rdv<u64>(pawn + OFF.Weapon);
    if (!wpn) return nil;
    i32 nameIdx = rdv<i32>(wpn + OFF.ObjectName);
    return fNameToString(nameIdx);
}

// ------------------------------------------------------------ frame build

void syncOffsets() { OFF = Config::off; }

void buildFrame() {
    Frame& f = g_frame;
    f.ready = false;
    f.entCount = 0;
    f.warnCount = 0;
    f.now = [NSDate date].timeIntervalSince1970;

    if (!SIG.gworld) return;
    u64 world = rdv<u64>(SIG.gworld);
    if (!world) return;
    u64 gameInstance = rdv<u64>(world + OFF.GameInstance);
    u64 lpArray = rdv<u64>(gameInstance + OFF.LocalPlayers);
    u64 localPlayer = lpArray ? rdv<u64>(lpArray) : 0;
    u64 pc = localPlayer ? rdv<u64>(localPlayer + OFF.PlayerController) : 0;
    g_localPC = pc;

    // watchdog: world alive but camera dead for ~1.2s -> version drift, go safe
    static int camMiss = 0;
    u64 camMgr = pc ? rdv<u64>(pc + OFF.PlayerCameraManager) : 0;
    if (world && !camMgr) {
        if (++camMiss > 150 && !g_sw.safeMode) {
            g_sw.safeMode = true;   // ESP-only fallback
            camMiss = 0;
            [@"watchdog: camera chain dead - switched to SafeMode"
                writeToFile:docPath(@"watchdog.txt")
                 atomically:YES encoding:NSUTF8StringEncoding error:nil];
        }
        return;
    }
    camMiss = 0;
    if (!camMgr) return;
    FMinView pov = rdv<FMinView>(camMgr + OFF.CameraCache + OFF.POV);
    if (!fine(pov.loc.x) || !fine(pov.loc.y) || !fine(pov.loc.z)) return;
    f.camLoc = pov.loc; f.camRot = pov.rot;
    f.fov = pov.fov > 1.f ? pov.fov : 90.f;

    CGSize sc = UIScreen.mainScreen.bounds.size;
    f.screenW = (int)sc.width; f.screenH = (int)sc.height;
    f.localPawn = pc ? rdv<u64>(pc + OFF.Pawn) : 0;
    f.localDead = (OFF.Health && f.localPawn) ? rdv<f32>(f.localPawn + OFF.Health) <= 0.5f : false;

    // local team
    f.localTeam = -1;
    u64 gs = rdv<u64>(world + OFF.GameState);
    if (gs && OFF.TeamOffset) {
        u64 arr = rdv<u64>(gs + OFF.PlayerArray);
        i32 cnt = rdv<i32>(gs + OFF.PlayerArray + 8);
        for (int i = 0; i < cnt && i < 64; ++i) {
            u64 ps = rdv<u64>(arr + (u64)i * 8);
            if (!ps) continue;
            if (rdv<u64>(ps + OFF.PawnPrivate) == f.localPawn) { f.localTeam = rdv<i32>(ps + OFF.TeamOffset); break; }
        }
    }

    // current weapon profile (cached per frame)
    NSString* wname = f.localPawn ? weaponNameFor(f.localPawn) : nil;
    g_curWeapon = Config::match(wname);

    // entities
    if (!gs) return;
    u64 arr = rdv<u64>(gs + OFF.PlayerArray);
    i32 cnt = rdv<i32>(gs + OFF.PlayerArray + 8);
    if (!arr || cnt <= 0) return;
    if (cnt > 32) cnt = 32;

    for (int i = 0; i < cnt; ++i) {
        u64 ps = rdv<u64>(arr + (u64)i * 8);
        if (!ps) continue;
        u64 pawn = rdv<u64>(ps + OFF.PawnPrivate);
        if (!pawn || pawn == f.localPawn) continue;
        u64 mesh = rdv<u64>(pawn + OFF.Mesh);
        if (!mesh) continue;

        // pawn class-name check (kiss-style FName matching): real players only,
        // robots/training dummies still shown but flagged
        bool botPawn = false;
        NSString* pawnCls = nil;
        if (OFF.ObjectName) {
            pawnCls = fNameToString(rdv<i32>(pawn + OFF.ObjectName));
            if (pawnCls) {
                botPawn = ![GameNames_players() containsObject:pawnCls.lowercaseString];
            }
        }

        Entity& e = f.ents[f.entCount];
        FTransform c2w = rdv<FTransform>(mesh + OFF.ComponentToWorld);
        if (!fine(c2w.pos.x) || !fine(c2w.pos.y) || !fine(c2w.pos.z)) continue;

        e.origin = c2w.pos;
        e.pawn = pawn;
        e.id = pawn;
        e.bot = botPawn;
        e.team = OFF.TeamOffset ? rdv<i32>(ps + OFF.TeamOffset) : 0;
        f64 dx = e.origin.x - f.camLoc.x, dy = e.origin.y - f.camLoc.y, dz = e.origin.z - f.camLoc.z;
        e.dist = sqrtf((f32)(dx*dx + dy*dy + dz*dz)) / 100.f;

        if (OFF.Health) {
            e.hp = rdv<f32>(pawn + OFF.Health);
            e.alive = e.hp > 0.5f;
        }

        // visibility heuristic: LastRenderTime ticking = rendered recently
        Tracker* tr = trackFor(pawn);
        f32 lr = OFF.LastRenderTime ? rdv<f32>(mesh + OFF.LastRenderTime) : 0.f;
        if (OFF.LastRenderTime && lr != tr->lastRenderPrev) { tr->lastSeenT = f.now; tr->lastRenderPrev = lr; }
        e.visible = (f.now - tr->lastSeenT) < 0.5;

        // velocity (m/s) from tracked position history
        if (tr->prevPosT > 0) {
            f64 dt = f.now - tr->prevPosT;
            if (dt > 0.001 && dt < 1.0)
                e.vel = { (e.origin.x - tr->prevPos.x)/(f32)dt/100.f,
                          (e.origin.y - tr->prevPos.y)/(f32)dt/100.f,
                          (e.origin.z - tr->prevPos.z)/(f32)dt/100.f };
        }
        tr->prevPos = e.origin; tr->prevPosT = f.now;

        // bones (encrypted or plain per config)
        u64 boneArr = rdv<u64>(mesh + OFF.BoneArray);
        i32 boneCnt = rdv<i32>(mesh + OFF.BoneCount);
        e.boneOk = false;
        if (boneArr && boneCnt > 0 && boneCnt <= BONE_MAX) {
            for (int b = 0; b < boneCnt; ++b) {
                u8 raw[48];
                if (!rd(boneArr + (u64)b * 48, raw, 48)) continue;
                FQuat q = decryptBoneQuat(raw, b);
                FVec lp = decryptBonePos(raw, b);
                FVec rot = quatRot(q, lp);
                e.bones[b] = {
                    c2w.pos.x + rot.x * c2w.scale.x,
                    c2w.pos.y + rot.y * c2w.scale.y,
                    c2w.pos.z + rot.z * c2w.scale.z,
                };
            }
            e.boneCount = boneCnt;
            e.boneOk = true;
            // head fallback: bone 67 if populated, else comp origin + 170cm
            e.head = (boneCnt > 67 && fine(e.bones[67].x)) ? e.bones[67]
                   : FVec{ c2w.pos.x, c2w.pos.y, c2w.pos.z + 170.f };
        } else {
            e.head = { c2w.pos.x, c2w.pos.y, c2w.pos.z + 170.f };
        }

        e.used = true;
        e.agentIcon = GameNames_agentIcon(pawnCls);
        e.weaponIcon = GameNames_weaponIcon(weaponNameFor(pawn));
        if (OFF.Armor) e.armor = rdv<f32>(pawn + OFF.Armor);
        f.entCount++;
    }
    f.ready = f.entCount >= 0 && camMgr != 0;

    // zero-touch calibration: first valid frame of a session -> auto-run AutoScan once
    static bool g_autoCalibrated = false;
    if (f.ready && !g_autoCalibrated) {
        g_autoCalibrated = true;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)),
                       dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{ autoScanStart(); });
    }

    // ---- warningObjects (kiss parity): round-robin scan of level actors ----
    f.warnCount = 0;
    if (g_sw.warning && OFF.PersistentLevel && OFF.Actors && OFF.RootComponent && OFF.ObjectName) {
        u64 level = rdv<u64>(world + OFF.PersistentLevel);
        if (level) {
            u64 actorArr = rdv<u64>(level + OFF.Actors);
            i32 actorCnt = rdv<i32>(level + OFF.Actors + 8);
            if (actorArr && actorCnt > 0 && actorCnt < 20000) {
                // scan a moving 256-actor window per frame (cross-process reads are pricey)
                static int g_warnCursor = 0;
                if (g_warnCursor >= actorCnt) g_warnCursor = 0;
                for (int k = 0; k < 256 && f.warnCount < 48; ++k) {
                    int i = (g_warnCursor + k) % actorCnt;
                    u64 actor = rdv<u64>(actorArr + (u64)i * 8);
                    if (!actor || actor == f.localPawn) continue;
                    NSString* cls = fNameToString(rdv<i32>(actor + OFF.ObjectName));
                    if (!cls) continue;
                    bool hit = false;
                    for (NSString* a in GameNames_abilities())
                        if ([cls containsString:a]) { hit = true; break; }
                    if (!hit) continue;
                    u64 rootC = rdv<u64>(actor + OFF.RootComponent);
                    if (!rootC) continue;
                    FTransform c2w = rdv<FTransform>(rootC + OFF.ComponentToWorld);
                    if (!fine(c2w.pos.x) || !fine(c2w.pos.y) || !fine(c2w.pos.z)) continue;
                    Warn& w = f.warns[f.warnCount++];
                    w.pos = c2w.pos;
                    w.cls = cls;
                }
                g_warnCursor = (g_warnCursor + 256) % actorCnt;
            }
        }
    }
}

// ------------------------------------------------------------ aim writer

void applyAimRotation(f32 dYaw, f32 dPitch) {
    if (!g_localPC || !OFF.ControlRotation) return;
    FRot cur = rdv<FRot>(g_localPC + OFF.ControlRotation);
    FRot next = { cur.pitch + dPitch, cur.yaw + dYaw, cur.roll };
    if (next.pitch > 89.9f) next.pitch = 89.9f;
    if (next.pitch < -89.9f) next.pitch = -89.9f;
    while (next.yaw > 180.f) next.yaw -= 360.f;
    while (next.yaw < -180.f) next.yaw += 360.f;
    wr(g_localPC + OFF.ControlRotation, &next, sizeof(FRot));  // real remote write
}

// ------------------------------------------------------------ sig dump

void doSigDump() {
    NSString* p = docPath(@"dump.txt");
    dumpSigReport((char*)p.fileSystemRepresentation);
}
