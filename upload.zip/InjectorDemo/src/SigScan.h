#pragma once
#include "UE.h"
#import <Foundation/Foundation.h>

// ARM64 in-memory pattern scanner + ADRP chain resolver.
// Sig patterns come from config.plist so each game build only needs a
// config edit — no recompile. Format: "1F 20 03 D5 ? ? 91" ('?' = wildcard).

struct SigTable {
    uintptr_t gworld   = 0;  // resolved address holding UWorld*
    uintptr_t gnames   = 0;  // FNamePool base
    uintptr_t guobject = 0;  // GUObjectArray (optional)
    uintptr_t decKey   = 0;  // bone-decrypt key table (optional, mode 1)
    bool allCore() const { return gworld && gnames; }
};

extern SigTable SIG;

bool sigScanAll(NSDictionary* sigDict /* plist sigs, may be nil */);
uintptr_t resolveAdrpChain(uintptr_t insnAddr); // adrp(+add|ldr) -> effective address
void dumpSigReport(const char* path);           // write candidate addresses + hex context
