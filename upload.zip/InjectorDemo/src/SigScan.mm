#import "SigScan.h"
#import "KRW.h"
#import "StrObf.h"
#import <Foundation/Foundation.h>
#import <mach/mach.h>
#import <stdio.h>

// remote signature scan: read the game's __TEXT / __DATA over the task port
// in 2 MB chunks and pattern-match locally.

SigTable SIG;

static bool parsePattern(NSString* pat, u8* bytes, char* mask, u32& len) {
    if (!pat) return false;
    len = 0;
    NSArray* toks = [pat componentsSeparatedByCharactersInSet:
                     [NSCharacterSet whitespaceCharacterSet]];
    for (NSString* t in toks) {
        if (t.length == 0) continue;
        if (len >= 256) return false;
        if ([t isEqualToString:@"?"] || [t isEqualToString:@"??"]) {
            bytes[len] = 0; mask[len] = '?'; len++;
        } else {
            bytes[len] = (u8)strtol([t UTF8String], nullptr, 16);
            mask[len] = 'x'; len++;
        }
    }
    return len > 0;
}

static uintptr_t findInRangeLocal(const u8* p, u64 size, const u8* bytes, const char* mask, u32 len) {
    if (size < len) return 0;
    u64 n = size - len;
    for (u64 i = 0; i <= n; ++i) {
        u32 j = 0;
        for (; j < len; ++j)
            if (mask[j] == 'x' && p[i + j] != bytes[j]) break;
        if (j == len) return (uintptr_t)i;
    }
    return (uintptr_t)-1;
}

// scan a remote range in chunks; returns absolute game address or 0
static uintptr_t findRemote(u64 base, u64 size, const u8* bytes, const char* mask, u32 len) {
    const u64 CHUNK = 2 * 1024 * 1024;
    const u64 OVERLAP = 256; // pattern can straddle chunk borders
    u8* buf = (u8*)malloc(CHUNK + OVERLAP);
    if (!buf) return 0;
    uintptr_t found = 0;
    u64 off = 0;
    while (off < size && !found) {
        u64 n = MIN(CHUNK + OVERLAP, size - off);
        // avoid crossing into unmapped tail on last chunk: trim to region end
        if (!rd(base + off, buf, n)) {
            if (n <= OVERLAP) break;
            n -= OVERLAP;              // retry without the tail overlap
            if (!rd(base + off, buf, n)) break;
        }
        uintptr_t rel = findInRangeLocal(buf, n, bytes, mask, len);
        if (rel != (uintptr_t)-1) found = base + off + rel;
        if (n < CHUNK + OVERLAP) break;
        off += CHUNK;
    }
    free(buf);
    return found;
}

uintptr_t resolveAdrpChain(uintptr_t insnAddr) {
    if (!insnAddr) return 0;
    u32 ins = rdv<u32>(insnAddr);
    // ADRP: op(1) immlo(2) 10000 immhi(19) Rd(5)
    if ((ins & 0x9F000000) != 0x90000000) return 0;
    int rd_n   = ins & 0x1F;
    int immlo = (ins >> 29) & 0x3;
    int immhi = (ins >> 5) & 0x7FFFF;
    i64 imm = (((i64)immhi << 2) | immlo) << 12;
    if (imm & (1LL << 32)) imm -= (1LL << 33);
    uintptr_t page = (insnAddr & ~(uintptr_t)0xFFF) + (uintptr_t)imm;

    u32 next = rdv<u32>(insnAddr + 4);
    // LDR Xt, [Xn, #imm12*8]
    if ((next & 0xFFC00000) == 0xF9400000 && (next & 0x1F) == rd_n) {
        u32 imm12 = (next >> 10) & 0xFFF;
        return page + (uintptr_t)(imm12 * 8); // pointer slot
    }
    // ADD Xd, Xn, #imm12
    if ((next & 0xFF000000) == 0x91000000 && ((next >> 5) & 0x1F) == rd_n) {
        u32 imm12 = (next >> 10) & 0xFFF;
        u32 shift = (next >> 22) & 1;
        return page + (uintptr_t)(imm12 << (shift ? 12 : 0));
    }
    return page;
}

bool sigScanAll(NSDictionary* sigs) {
    u64 textSize = 0, textBase = 0, dataBase = 0, dataSize = 0;
    if (!krwRegions(textBase, textSize, dataBase, dataSize)) return false;
    g_gameBase = textBase;
    g_gameTextSize = textSize;

    struct Entry { const char* key; uintptr_t* out; const char* fallback; };
    Entry entries[] = {
        { "GWorld",   &SIG.gworld,   "1F 05 00 71 ? ? ? 54 08 00 40 F9 ? ? ? 91" },
        { "GNames",   &SIG.gnames,   "? ? ? 90 ? ? ? 91 ? ? ? 14 1F 05 00 71" },
        { "GUObject", &SIG.guobject, nullptr },
        { "DecKey",   &SIG.decKey,   nullptr },
    };

    bool coreOk = true;
    for (auto& e : entries) {
        NSString* pat = sigs ? sigs[@(e.key)] : nil;
        if (!pat.length && e.fallback) pat = @(e.fallback);
        u8 bytes[256]; char mask[256]; u32 len = 0;
        if (!parsePattern(pat, bytes, mask, len)) { if (e.out == &SIG.gworld) coreOk = false; continue; }

        uintptr_t hit = findRemote(textBase, textSize, bytes, mask, len);
        if (!hit && dataBase && dataSize)
            hit = findRemote(dataBase, dataSize, bytes, mask, len);
        if (hit) {
            uintptr_t eff = resolveAdrpChain(hit);
            *e.out = eff ? eff : hit;
        } else if (e.out == &SIG.gworld || e.out == &SIG.gnames) {
            coreOk = false;
        }
    }
    return coreOk;
}

static void hexline(FILE* f, u64 addr) {
    u8 p[16];
    if (!rd(addr, p, 16)) { fprintf(f, "%016llx: <unreadable>\n", (unsigned long long)addr); return; }
    fprintf(f, "%016llx: ", (unsigned long long)addr);
    for (int i = 0; i < 16; ++i) fprintf(f, "%02X ", p[i]);
    fprintf(f, "\n");
}

void dumpSigReport(const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) return;
    fprintf(f, "game pid %d base %016llx textsize %llu\n",
            g_gamePid, (unsigned long long)g_gameBase, (unsigned long long)g_gameTextSize);
    fprintf(f, "GWorld   %016llx -> %016llx\n", (unsigned long long)SIG.gworld,
            SIG.gworld ? (unsigned long long)rdv<u64>(SIG.gworld) : 0);
    fprintf(f, "GNames   %016llx\n", (unsigned long long)SIG.gnames);
    fprintf(f, "GUObject %016llx\n", (unsigned long long)SIG.guobject);
    fprintf(f, "DecKey   %016llx\n", (unsigned long long)SIG.decKey);
    u64 targets[2] = { SIG.gworld, SIG.gnames };
    for (int t = 0; t < 2; ++t) {
        if (!targets[t]) continue;
        fprintf(f, "--- context @ %016llx ---\n", (unsigned long long)targets[t]);
        for (int row = -3; row <= 3; ++row)
            hexline(f, targets[t] + row * 16);
    }
    fclose(f);
}
