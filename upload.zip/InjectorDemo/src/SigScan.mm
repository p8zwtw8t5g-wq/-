#import "SigScan.h"
#import "StrObf.h"
#import <Foundation/Foundation.h>
#import <mach-o/dyld.h>
#import <mach-o/getsect.h>
#import <mach-o/loader.h>
#import <stdio.h>

SigTable SIG;

uintptr_t mainImageBase(u64& sizeOut) {
    sizeOut = 0;
    for (u32 i = 0; i < _dyld_image_count(); ++i) {
        const char* name = _dyld_get_image_name(i);
        if (!name) continue;
        // main executable = first entry, or anything that's not a dylib in the shared cache dirs
        if (i == 0 || strstr(name, "/var/containers/Bundle/Application/") != nullptr) {
            const struct mach_header_64* hdr = (const struct mach_header_64*)_dyld_get_image_header(i);
            if (hdr && hdr->magic == MH_MAGIC_64) {
                unsigned long sz = 0;
                getsegmentdata(hdr, SEG_TEXT, &sz);
                sizeOut = sz;
                return (uintptr_t)hdr;
            }
        }
    }
    return 0;
}

static bool parsePattern(NSString* pat, u8* bytes, char* mask, u32& len) {
    if (!pat) return false;
    len = 0;
    NSArray* toks = [pat componentsSeparatedByCharactersInSet:
                     [NSCharacterSet whitespaceCharacterSet]];
    for (NSString* t in toks) {
        if (t.length == 0) continue;
        if (len >= 256) return false;
        if ([t isEqualToString:@"?"] || [t isEqualToString:@"??"]) {
            bytes[len] = 0; mask[len] = '?'; len++;
        } else {
            bytes[len] = (u8)strtol([t UTF8String], nullptr, 16);
            mask[len] = 'x'; len++;
        }
    }
    return len > 0;
}

static uintptr_t findInRange(uintptr_t base, u64 size, const u8* bytes, const char* mask, u32 len) {
    if (!base || size < len) return 0;
    u8* p = (u8*)base;
    u64 n = size - len;
    for (u64 i = 0; i <= n; ++i) {
        u32 j = 0;
        for (; j < len; ++j) {
            if (mask[j] == 'x' && p[i + j] != bytes[j]) break;
        }
        if (j == len) return base + i;
    }
    return 0;
}

uintptr_t resolveAdrpChain(uintptr_t insnAddr) {
    if (!insnAddr) return 0;
    u32 ins = *(u32*)insnAddr;
    // ADRP: op(1) immlo(2) 10000 immhi(19) Rd(5) -> 1xx1 0000 ...
    if ((ins & 0x9F000000) != 0x90000000) return 0;
    int rd   = ins & 0x1F;
    int immlo = (ins >> 29) & 0x3;
    int immhi = (ins >> 5) & 0x7FFFF;
    i64 imm = (((i64)immhi << 2) | immlo) << 12;
    if (imm & (1LL << 32)) imm -= (1LL << 33);
    uintptr_t page = (insnAddr & ~(uintptr_t)0xFFF) + (uintptr_t)imm;

    u32 next = *(u32*)(insnAddr + 4);
    // LDR Xt, [Xn, #imm12*8]  (0xF9400000, mask 0xFFC00000, size=11 V=0 opc=01)
    if ((next & 0xFFC00000) == 0xF9400000 && (next & 0x1F) == rd) {
        u32 imm12 = (next >> 10) & 0xFFF;
        uintptr_t slot = page + (uintptr_t)(imm12 * 8);
        return slot; // address of the pointer slot
    }
    // ADD Xd, Xn, #imm12 (0x91000000, mask 0xFF000000)
    if ((next & 0xFF000000) == 0x91000000 && ((next >> 5) & 0x1F) == rd) {
        u32 imm12 = (next >> 10) & 0xFFF;
        u32 shift = (next >> 22) & 1;
        return page + (uintptr_t)(imm12 << (shift ? 12 : 0));
    }
    return page;
}

bool sigScanAll(NSDictionary* sigs) {
    u64 textSize = 0;
    uintptr_t base = mainImageBase(textSize);
    if (!base) return false;

    struct Entry { const char* key; uintptr_t* out; const char* fallback; };
    Entry entries[] = {
        { "GWorld",   &SIG.gworld,   "1F 05 00 71 ? ? ? 54 08 00 40 F9 ? ? ? 91" },
        { "GNames",   &SIG.gnames,   "? ? ? 90 ? ? ? 91 ? ? ? 14 1F 05 00 71" },
        { "GUObject", &SIG.guobject, nullptr },
        { "DecKey",   &SIG.decKey,   nullptr },
    };

    bool coreOk = true;
    for (auto& e : entries) {
        NSString* pat = sigs ? sigs[@(e.key)] : nil;
        if (!pat.length && e.fallback) pat = @(e.fallback);
        u8 bytes[256]; char mask[256]; u32 len = 0;
        if (!parsePattern(pat, bytes, mask, len)) { if (e.out == &SIG.gworld) coreOk = false; continue; }

        uintptr_t hit = 0;
        // try __TEXT then whole mapped range (some globals are referenced from __DATA stubs)
        hit = findInRange(base, textSize, bytes, mask, len);
        if (!hit) {
            // data scan: GNames/GWorld may sit behind a stub in __DATA
            unsigned long dsz = 0;
            uintptr_t dbase = (uintptr_t)getsegmentdata((const struct mach_header_64*)base, SEG_DATA, &dsz);
            if (dbase && dsz) hit = findInRange(dbase, dsz, bytes, mask, len);
        }
        if (hit) {
            uintptr_t eff = resolveAdrpChain(hit);
            *e.out = eff ? eff : hit;
        } else if (e.out == &SIG.gworld || e.out == &SIG.gnames) {
            coreOk = false;
        }
    }
    return coreOk;
}

static void hexline(FILE* f, uintptr_t addr, const u8* p, int n) {
    fprintf(f, "%016llx: ", (unsigned long long)addr);
    for (int i = 0; i < n; ++i) fprintf(f, "%02X ", p[i]);
    fprintf(f, "\n");
}

void dumpSigReport(const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) return;
    u64 tsz = 0;
    uintptr_t base = mainImageBase(tsz);
    fprintf(f, "image base %016llx textsize %llu\n", (unsigned long long)base, (unsigned long long)tsz);
    fprintf(f, "GWorld   %016llx -> %016llx\n", (unsigned long long)SIG.gworld, SIG.gworld ? (unsigned long long)*(u64*)SIG.gworld : 0);
    fprintf(f, "GNames   %016llx\n", (unsigned long long)SIG.gnames);
    fprintf(f, "GUObject %016llx\n", (unsigned long long)SIG.guobject);
    fprintf(f, "DecKey   %016llx\n", (unsigned long long)SIG.decKey);
    uintptr_t targets[2] = { SIG.gworld, SIG.gnames };
    for (int t = 0; t < 2; ++t) {
        if (!targets[t]) continue;
        fprintf(f, "--- context @ %016llx ---\n", (unsigned long long)targets[t]);
        for (int row = -3; row <= 3; ++row)
            hexline(f, targets[t] + row * 16, (const u8*)(targets[t] + row * 16), 16);
    }
    fclose(f);
}
