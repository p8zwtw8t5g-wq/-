#pragma once
#include <string>
#include <array>
#include <cstddef>

// compile-time XOR string obfuscation: no plaintext in __cstring.
// anti-scan layer — the game's integrity sweep looks for known loader strings.
namespace obf {

constexpr std::size_t NMAX = 256;

template<std::size_t N>
struct Encoded {
    std::array<char, N> d;
    static constexpr std::size_t len = N;
    constexpr Encoded(const char (&s)[N]) : d{} {
        for (std::size_t i = 0; i < N; ++i) d[i] = (char)(s[i] ^ (char)(0x33 + (i & 0x1F)));
    }
};

template<std::size_t N>
constexpr auto encode(const char (&s)[N]) { return Encoded<N>(s); }

template<std::size_t N>
inline std::string decode(const Encoded<N>& e) {
    std::string out;
    out.reserve(N - 1);
    for (std::size_t i = 0; i + 1 < N; ++i) out += (char)(e.d[i] ^ (char)(0x33 + (i & 0x1F)));
    return out;
}

} // namespace obf

#define OBF(s) (obf::decode(obf::encode(s)))
