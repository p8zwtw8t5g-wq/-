#pragma once
#import <CoreGraphics/CoreGraphics.h>

// global touch monitor: UIApplication sendEvent: is swizzled with the ObjC
// runtime, so we see every touch in the process (game touches included).
// Each UITouch* is stable for the whole gesture — that IS the touch ID.
// No substrate/ellekit dependency.

struct TouchInfo {
    uintptr_t id;    // UITouch pointer, stable across began/move/end
    float     x, y;  // window coords
    double    t0;    // touch-down timestamp
    bool      down;
};

extern TouchInfo g_touches[12];
extern int       g_touchCount;
extern bool      g_aimTrigger;    // evaluated every frame from mode+state
extern bool      g_ballPressed;   // set by floating-ball gesture (Overlay)
extern float     g_ballX, g_ballY;

enum TriggerMode : int {
    TRIG_BALL   = 1 << 0,
    TRIG_ZONE   = 1 << 1,
    TRIG_SECOND = 1 << 2, // any 2+ simultaneous touches = firing finger engaged
};

bool touchMonInit();     // call once on main thread (swizzles sendEvent:)
void touchMonEval();     // recompute g_aimTrigger; call each frame
void touchMonSetModes(int mask);
void touchMonSetZone(CGRect z);
int  secondFingerHeldCount();
