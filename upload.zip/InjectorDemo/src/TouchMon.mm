#import "TouchMon.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <string.h>

TouchInfo g_touches[12];
int       g_touchCount = 0;
bool      g_aimTrigger = false;
bool      g_ballPressed = false;
float     g_ballX = 0, g_ballY = 0;
uintptr_t g_ballTouchId = 0; // set by Overlay while finger presses the ball

static int    g_modes = TRIG_BALL | TRIG_SECOND;
static CGRect g_zone;
static double g_secTouchMin = 0.12; // s: ignore instant second-finger taps

static double nowS() { return [NSDate date].timeIntervalSince1970; }

// previous-frame snapshot for touch-down continuity (t0 per touch ID)
static TouchInfo g_prev[12];
static int       g_prevN = 0;

// UIApplication sendEvent: is swizzled with the ObjC runtime — no substrate/
// ellekit dependency, works on any jailbreak.
static IMP g_origSendEvent = NULL;

static void hook_sendEvent(UIApplication* self, SEL _cmd, UIEvent* ev) {
    if (g_origSendEvent) ((void (*)(id, SEL, UIEvent*))g_origSendEvent)(self, _cmd, ev);

    double t = nowS();
    int n = 0;
    for (UITouch* touch in ev.allTouches) {
        if (n >= 12) break;
        TouchInfo& ti = g_touches[n];
        ti.id = (uintptr_t)touch; // stable across the gesture = touch ID
        CGPoint p = [touch locationInView:nil];
        ti.x = p.x; ti.y = p.y;
        ti.down = (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled);

        // keep t0 from the snapshot; fresh touch id -> t0 = now
        double t0 = t;
        for (int k = 0; k < g_prevN; ++k)
            if (g_prev[k].id == ti.id) { t0 = g_prev[k].t0; break; }
        ti.t0 = t0;
        n++;
    }
    g_touchCount = n;
    memcpy(g_prev, g_touches, sizeof(g_touches));
    g_prevN = n;
}

bool touchMonInit() {
    Class cls = objc_getClass("UIApplication");
    if (!cls) return false;
    Method m = class_getInstanceMethod(cls, @selector(sendEvent:));
    if (!m) return false;
    g_origSendEvent = method_getImplementation(m);
    method_setImplementation(m, (IMP)hook_sendEvent);
    return true;
}

void touchMonSetModes(int mask) { g_modes = mask; }
void touchMonSetZone(CGRect z)  { g_zone = z; }

int secondFingerHeldCount() {
    int c = 0;
    double t = nowS();
    for (int i = 0; i < g_touchCount; ++i)
        if (g_touches[i].down && g_touches[i].id != g_ballTouchId
            && (t - g_touches[i].t0) > g_secTouchMin) c++;
    return c;
}

void touchMonEval() {
    bool trig = false;
    if ((g_modes & TRIG_BALL) && g_ballPressed) trig = true;
    if (!trig && (g_modes & TRIG_ZONE)) {
        for (int i = 0; i < g_touchCount; ++i)
            if (g_touches[i].down && CGRectContainsPoint(g_zone, CGPointMake(g_touches[i].x, g_touches[i].y))) { trig = true; break; }
    }
    if (!trig && (g_modes & TRIG_SECOND) && secondFingerHeldCount() >= 1) trig = true;
    g_aimTrigger = trig;
}
