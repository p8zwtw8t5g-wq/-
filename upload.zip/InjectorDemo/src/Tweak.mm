#import "UE.h"
#import "Config.h"
#import "Overlay.h"
#import "TouchMon.h"
#import "AutoScan.h"
#import "SigScan.h"
#import "Aim.h"
#import "StrObf.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <mach/mach.h>
#import <stdio.h>

Offsets OFF; // UE.h extern (kept in sync with Config::off)

NSString* g_skeletonPairs = @"";
static NSString* g_gamePath = nil;

// persistent per-pawn tracker: render-freshness + velocity estimation
struct Tracker {
    uintptr_t pawn;
    f32 lastRenderPrev;
    f64 lastSeenT;
    FVec prevPos;
    f64 prevPosT;
};
static Tracker g_track[64];
static Tracker* trackFor(uintptr_t pawn) {
    for (auto& t : g_track) if (t.pawn == pawn) return &t;
    for (auto& t : g_track) if (!t.pawn) { t = {}; t.pawn = pawn; return &t; }
    static int rr = 0; Tracker& t = g_track[rr++ & 63]; t = {}; t.pawn = pawn; return &t;
}

WeaponProfile* g_curWeapon = nil;
WeaponProfile* currentWeaponProfile() { return g_curWeapon ? g_curWeapon : &Config::def; }

static inline bool rd(u64 addr, void* out, u64 sz) {
    if (!addr) return false;
    memcpy(out, (void*)addr, sz);
    return true;
}
template<typename T> static inline T rdv(u64 addr, T dflt = T{}) {
    T v; if (!rd(addr, &v, sizeof(T))) return dflt; return v;
}

// ------------------------------------------------------------ FName decode

NSString* fNameToString(i32 index) {
    if (!SIG.gnames || index < 0) return nil;
    u32 stride = OFF.NameStride ? OFF.NameStride : 2;
    u32 blockIdx = (u32)index >> 16;
    u32 off16    = (u32)index & 0xFFFF;
    u64 block = rdv<u64>(SIG.gnames + 8 + (u64)blockIdx * 8);
    if (!block) return nil;
    u64 entry = block + (u64)off16 * stride;
    u16 header = rdv<u16>(entry);
    u32 len = header >> OFF.NameLenShift;
    if (len <= 0 || len > 128) return nil;
    bool wide = header & 1;
    char buf[256];
    if (wide) {
        u64 src = entry + 2;
        u16 wbuf[128]; rd(src, wbuf, len * 2);
        for (u32 i = 0; i < len && i < 128; ++i) buf[i] = (char)wbuf[i];
        buf[len < 128 ? len : 127] = 0;
    } else {
        rd(entry + 2, buf, len);
        buf[len < 255 ? len : 255] = 0;
    }
    if (OFF.NameXorKey) {
        u32 k = OFF.NameXorKey;
        for (u32 i = 0; buf[i]; ++i) buf[i] ^= (char)(k + i);
    }
    return [NSString stringWithUTF8String:buf];
}

// ------------------------------------------------------------ bone decrypt

static FVec decryptBonePos(const u8* raw, int boneIdx) {
    switch (Config::decryptMode) {
    case 1: { // rolling XOR with key table (Tencent-style runtime obfuscation)
        if (!SIG.decKey) { FVec v; memcpy(&v, raw + 0x10, 12); return v; }
        u32 k = rdv<u32>(SIG.decKey + ((u32)boneIdx * 4 & 0xFF));
        FVec v; memcpy(&v, raw + 0x10, 12);
        u32* p = (u32*)&v;
        p[0] ^= k;
        p[1] ^= (k << 7) | (k >> 25);
        p[2] ^= (k << 13) | (k >> 19);
        return v;
    }
    case 2: { // 48-bit packed: quat as 3x i16, pos as 3x i16 (scale from config build)
        struct Packed { i16 qx, qy, qz, px, py, pz; } pk;
        memcpy(&pk, raw, sizeof(Packed));
        FVec qn = { pk.qx / 32767.f, pk.qy / 32767.f, pk.qz / 32767.f };
        f32 w2 = 1.f - qn.x*qn.x - qn.y*qn.y - qn.z*qn.z;
        FVec pos = { pk.px * 0.1f, pk.py * 0.1f, pk.pz * 0.1f };
        (void)w2; (void)qn; // quat unused for position output
        return pos;
    }
    default: { // plain FTransform layout: quat@0, pos@0x10
        FVec v; memcpy(&v, raw + 0x10, 12);
        return v;
    }
    }
}

static FQuat decryptBoneQuat(const u8* raw, int boneIdx) {
    switch (Config::decryptMode) {
    case 2: {
        struct Packed { i16 qx, qy, qz, px, py, pz; } pk;
        memcpy(&pk, raw, sizeof(Packed));
        FVec qn = { pk.qx / 32767.f, pk.qy / 32767.f, pk.qz / 32767.f };
        f32 w2 = 1.f - qn.x*qn.x - qn.y*qn.y - qn.z*qn.z;
        return { qn.x, qn.y, qn.z, w2 > 0 ? sqrtf(w2) : 0.f };
    }
    case 1: {
        FQuat q; memcpy(&q, raw, 16);
        if (SIG.decKey) {
            u32 k = rdv<u32>(SIG.decKey + ((u32)(boneIdx + 97) * 4 & 0xFF));
            u32* p = (u32*)&q;
            p[0] ^= k; p[1] ^= (k << 11) | (k >> 21);
            p[2] ^= (k << 17) | (k >> 15); p[3] ^= (k << 3) | (k >> 29);
        }
        return q;
    }
    default: { FQuat q; memcpy(&q, raw, 16); return q; }
    }
}

static FQuat quatConj(const FQuat& q) { return { -q.x, -q.y, -q.z, q.w }; }
static FVec quatRot(const FQuat& q, const FVec& v) {
    // v' = q * v * q^-1 (optimized 3D rotation)
    FVec u = { q.x, q.y, q.z };
    f32 uv = u.x*v.x + u.y*v.y + u.z*v.z;
    f32 uu = u.x*u.x + u.y*u.y + u.z*u.z;
    f32 w2 = q.w * q.w;
    FVec t = { u.y*v.z - u.z*v.y, u.z*v.x - u.x*v.z, u.x*v.y - u.y*v.x };
    return {
        2*w2*v.x + 2*uv*u.x + 2*(uu - w2)*t.x,
        2*w2*v.y + 2*uv*u.y + 2*(uu - w2)*t.y,
        2*w2*v.z + 2*uv*u.z + 2*(uu - w2)*t.z,
    };
}

// ------------------------------------------------------------ weapon name

static NSString* weaponNameFor(uintptr_t pawn) {
    if (!OFF.Weapon) return nil;
    u64 wpn = rdv<u64>(pawn + OFF.Weapon);
    if (!wpn) return nil;
    i32 nameIdx = rdv<i32>(wpn + OFF.ObjectName);
    return fNameToString(nameIdx);
}

// ------------------------------------------------------------ frame build

void buildFrame() {
    Frame& f = g_frame;
    f.now = [NSDate date].timeIntervalSince1970;
    f.ready = false;
    f.entCount = 0;
    if (!SIG.gworld) return;

    u64 world = rdv<u64>(SIG.gworld);
    if (!world) return;

    // camera via LocalPlayer chain
    u64 gameInstance = rdv<u64>(world + OFF.GameInstance);
    u64 lpArray = rdv<u64>(gameInstance + OFF.LocalPlayers);
    u64 localPlayer = lpArray ? rdv<u64>(lpArray) : 0;
    u64 pc = localPlayer ? rdv<u64>(localPlayer + OFF.PlayerController) : 0;
    g_localPC = pc;

    // touch-drive: (re)resolve native input functions when the controller changes
    if (pc && pc != tdResolvedForPC && Config::aimTouch) resolveTouchDrive(pc);

    // watchdog: world alive but camera dead for ~1.2s -> version drift, go safe
    static int camMiss = 0;
    u64 camMgr = pc ? rdv<u64>(pc + OFF.PlayerCameraManager) : 0;
    if (world && !camMgr) {
        if (++camMiss > 150 && !g_sw.safeMode) {
            g_sw.safeMode = true;   // ESP-only fallback
            camMiss = 0;
            [@"watchdog: camera chain dead - switched to SafeMode"
                writeToFile:@"/var/jb/share/InjectorDemo/watchdog.txt"
                 atomically:YES encoding:NSUTF8StringEncoding error:nil];
        }
        return;
    }
    camMiss = 0;
    if (!camMgr) return;
    FMinView pov = rdv<FMinView>(camMgr + OFF.CameraCache + OFF.POV);
    if (!fine(pov.loc.x) || !fine(pov.loc.y) || !fine(pov.loc.z)) return;
    f.camLoc = pov.loc; f.camRot = pov.rot;
    f.fov = pov.fov > 1.f ? pov.fov : 90.f;

    CGSize sc = UIScreen.mainScreen.bounds.size;
    f.screenW = (int)sc.width; f.screenH = (int)sc.height;
    f.localPawn = pc ? rdv<u64>(pc + OFF.Pawn) : 0;
    f.localDead = (OFF.Health && f.localPawn) ? rdv<f32>(f.localPawn + OFF.Health) <= 0.5f : false;

    // local team
    f.localTeam = -1;
    u64 gs = rdv<u64>(world + OFF.GameState);
    if (gs && OFF.TeamOffset) {
        u64 arr = rdv<u64>(gs + OFF.PlayerArray);
        i32 cnt = rdv<i32>(gs + OFF.PlayerArray + 8);
        for (int i = 0; i < cnt && i < 64; ++i) {
            u64 ps = rdv<u64>(arr + (u64)i * 8);
            if (!ps) continue;
            if (rdv<u64>(ps + OFF.PawnPrivate) == f.localPawn) { f.localTeam = rdv<i32>(ps + OFF.TeamOffset); break; }
        }
    }

    // current weapon profile (cached per frame)
    NSString* wname = f.localPawn ? weaponNameFor(f.localPawn) : nil;
    g_curWeapon = Config::match(wname);

    // entities
    if (!gs) return;
    u64 arr = rdv<u64>(gs + OFF.PlayerArray);
    i32 cnt = rdv<i32>(gs + OFF.PlayerArray + 8);
    if (!arr || cnt <= 0) return;
    if (cnt > 32) cnt = 32;

    for (int i = 0; i < cnt; ++i) {
        u64 ps = rdv<u64>(arr + (u64)i * 8);
        if (!ps) continue;
        u64 pawn = rdv<u64>(ps + OFF.PawnPrivate);
        if (!pawn || pawn == f.localPawn) continue;
        u64 mesh = rdv<u64>(pawn + OFF.Mesh);
        if (!mesh) continue;

        Entity& e = f.ents[f.entCount];
        FTransform c2w = rdv<FTransform>(mesh + OFF.ComponentToWorld);
        if (!fine(c2w.pos.x) || !fine(c2w.pos.y) || !fine(c2w.pos.z)) continue;

        e.origin = c2w.pos;
        e.pawn = pawn;
        e.id = pawn;
        e.team = OFF.TeamOffset ? rdv<i32>(ps + OFF.TeamOffset) : 0;
        f64 dx = e.origin.x - f.camLoc.x, dy = e.origin.y - f.camLoc.y, dz = e.origin.z - f.camLoc.z;
        e.dist = sqrtf((f32)(dx*dx + dy*dy + dz*dz)) / 100.f;

        if (OFF.Health) {
            e.hp = rdv<f32>(pawn + OFF.Health);
            e.alive = e.hp > 0.5f;
        }

        // visibility heuristic: LastRenderTime ticking = rendered recently
        Tracker* tr = trackFor(pawn);
        f32 lr = OFF.LastRenderTime ? rdv<f32>(mesh + OFF.LastRenderTime) : 0.f;
        if (OFF.LastRenderTime && lr != tr->lastRenderPrev) { tr->lastSeenT = f.now; tr->lastRenderPrev = lr; }
        e.visible = (f.now - tr->lastSeenT) < 0.5;

        // velocity (m/s) from tracked position history
        if (tr->prevPosT > 0) {
            f64 dt = f.now - tr->prevPosT;
            if (dt > 0.001 && dt < 1.0)
                e.vel = { (e.origin.x - tr->prevPos.x)/(f32)dt/100.f,
                          (e.origin.y - tr->prevPos.y)/(f32)dt/100.f,
                          (e.origin.z - tr->prevPos.z)/(f32)dt/100.f };
        }
        tr->prevPos = e.origin; tr->prevPosT = f.now;

        // bones (encrypted or plain per config)
        u64 boneArr = rdv<u64>(mesh + OFF.BoneArray);
        i32 boneCnt = rdv<i32>(mesh + OFF.BoneCount);
        e.boneOk = false;
        if (boneArr && boneCnt > 0 && boneCnt <= BONE_MAX) {
            for (int b = 0; b < boneCnt; ++b) {
                const u8* raw = (const u8*)(boneArr + (u64)b * 48);
                FQuat q = decryptBoneQuat(raw, b);
                FVec lp = decryptBonePos(raw, b);
                FVec rot = quatRot(q, lp);
                e.bones[b] = {
                    c2w.pos.x + rot.x * c2w.scale.x,
                    c2w.pos.y + rot.y * c2w.scale.y,
                    c2w.pos.z + rot.z * c2w.scale.z,
                };
            }
            e.boneCount = boneCnt;
            e.boneOk = true;
            // head fallback: bone 67 if populated, else comp origin + 170cm
            e.head = (boneCnt > 67 && fine(e.bones[67].x)) ? e.bones[67]
                   : FVec{ c2w.pos.x, c2w.pos.y, c2w.pos.z + 170.f };
        } else {
            e.head = { c2w.pos.x, c2w.pos.y, c2w.pos.z + 170.f };
        }

        e.used = true;
        f.entCount++;
    }
    f.ready = f.entCount >= 0 && camMgr != 0;

    // zero-touch calibration: first valid frame of a session -> auto-run AutoScan once
    static bool g_autoCalibrated = false;
    if (f.ready && !g_autoCalibrated) {
        g_autoCalibrated = true;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)),
                       dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{ autoScanStart(); });
    }
}

// ------------------------------------------------------------ aim writer

// --- touch-drive: feed the game's own AddYawInput/AddPitchInput so the aim
// goes through the native input pipeline (sensitivity, smoothing, replay) ---
bool g_tdReady = false;
static u64 tdInput = 0, tdYawFn = 0, tdPitchFn = 0, tdPE = 0;
static u64 tdResolvedForPC = 0;

typedef void (*ProcessEvent_t)(void*, void*, void*);

// walk a UStruct's FField chain collecting UFunctions by name
static u64 findUFunction(u64 obj, NSString* funcName) {
    u64 cls = rdv<u64>(obj + OFF.ClassPrivate);
    u64 field = cls ? rdv<u64>(cls + OFF.Children) : 0;
    int depth = 0;
    while (field && depth++ < 2000) {
        i32 n = rdv<i32>(field + OFF.FieldName);
        NSString* nm = fNameToString(n);
        if (nm && [nm isEqualToString:funcName]) return field;
        field = rdv<u64>(field + OFF.FieldNext);
    }
    return 0;
}

static void resolveTouchDrive(u64 pc) {
    g_tdReady = false;
    tdInput = tdYawFn = tdPitchFn = tdPE = 0;
    if (!pc || !OFF.PEVtableIndex) return;

    // PlayerInput object somewhere in PlayerController
    for (u32 off = 0x20; off + 8 <= 0x300; off += 8) {
        u64 p = rdv<u64>(pc + off);
        if (!p || p < 0x100000) continue;
        i32 n = rdv<i32>(p + OFF.ObjectName);
        NSString* cn = nil;
        u64 cls = rdv<u64>(p + OFF.ClassPrivate);
        if (cls) cn = fNameToString(rdv<i32>(cls + OFF.ObjectName));
        if (cn && [cn rangeOfString:@"PlayerInput" options:NSCaseInsensitiveSearch].location != NSNotFound) {
            tdInput = p; break;
        }
    }
    if (!tdInput) return;

    tdYawFn   = findUFunction(tdInput, @"AddYawInput");
    tdPitchFn = findUFunction(tdInput, @"AddPitchInput");
    if (!tdYawFn || !tdPitchFn) return;

    u64 vtable = rdv<u64>(tdInput);
    tdPE = vtable ? rdv<u64>(vtable + (u64)OFF.PEVtableIndex * 8) : 0;
    g_tdReady = (tdPE != 0);
    tdResolvedForPC = pc;
}

void touchDriveFeed(f32 yawIn, f32 pitchIn) {
    if (!g_tdReady || !tdPE) return;
    f32 y = yawIn, p = pitchIn;
    ((ProcessEvent_t)tdPE)((void*)tdInput, (void*)tdYawFn,   &y);
    ((ProcessEvent_t)tdPE)((void*)tdInput, (void*)tdPitchFn, &p);
}

void applyAimRotation(f32 dYaw, f32 dPitch) {
    if (!g_localPC || !OFF.ControlRotation) return;
    FRot cur = rdv<FRot>(g_localPC + OFF.ControlRotation);
    FRot next = { cur.pitch + dPitch, cur.yaw + dYaw, cur.roll };
    if (next.pitch > 89.9f) next.pitch = 89.9f;
    if (next.pitch < -89.9f) next.pitch = -89.9f;
    while (next.yaw > 180.f) next.yaw -= 360.f;
    while (next.yaw < -180.f) next.yaw += 360.f;
    rd(g_localPC + OFF.ControlRotation, &next, sizeof(FRot));
}

// ------------------------------------------------------------ sig dump

void doSigDump() {
    dumpSigReport("/var/jb/share/InjectorDemo/dump.txt");
}

// ------------------------------------------------------------ boot

static void syncOffsets() { OFF = Config::off; }

__attribute__((constructor)) static void injectorDemoCtor() {
    // SafeMode latch: volume-down during injection window is handled by the panel;
    // env latch for scripted runs
    if (getenv("INJECTOR_SAFE")) g_sw.safeMode = true;

    dispatch_async(dispatch_get_main_queue(), ^{
        Config::load();
        autoScanApplySaved(); // previous scan results (manual config wins)
        syncOffsets();
        g_skeletonPairs = @""; // set below from config if present
        if (NSDictionary* root = [NSDictionary dictionaryWithContentsOfFile:@"/var/jb/share/InjectorDemo/config.plist"])
            g_skeletonPairs = root[@"skeletonPairs"] ?: @"";
        sigScanAll(Config::sigs);
        g_curWeapon = &Config::def;
        startOverlay();
        touchMonInit(); // global touch monitor (touch IDs + trigger eval)
    });
}
