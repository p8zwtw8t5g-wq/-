#pragma once
#include <cstdint>
#include <cmath>

typedef float    f32;
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int32_t  i32;

struct FVec  { f32 x, y, z; };
struct FRot  { f32 pitch, yaw, roll; };
struct FQuat { f32 x, y, z, w; };

// UE4 FTransform: quat(16) + pos(12)+pad(4) + scale(12)+pad(4) = 48 bytes
struct FTransform { FQuat q; FVec pos; u32 pad0; FVec scale; u32 pad1; };

// FMinimalViewInfo (POV slice used by cheats): loc + rot + scale + fov
struct FMinView { FVec loc; FRot rot; f32 scale; f32 fov; };

constexpr int BONE_MAX = 96;

// All member offsets are plist-overridable at runtime (see config.plist).
// Defaults are UE4.26/4.27 mobile reference values; every build can shift.
struct Offsets {
    u32 GameState          = 0x140;  // UWorld -> GameState
    u32 GameInstance       = 0x1B0;  // UWorld -> OwningGameInstance
    u32 LocalPlayers       = 0x38;   // UGameInstance -> LocalPlayers (TArray<ULocalPlayer*>)
    u32 PlayerController   = 0x30;   // ULocalPlayer -> PlayerController
    u32 Pawn               = 0x2A8;  // APlayerController -> AcknowledgedPawn/Pawn
    u32 PlayerCameraManager= 0x2C0;  // APlayerController -> PlayerCameraManager
    u32 CameraCache        = 0x1AF0; // APlayerCameraManager -> CameraCachePrivate
    u32 POV                = 0x10;   // FCameraCacheEntry -> FMinimalViewInfo

    u32 PlayerArray        = 0x2A8;  // AGameStateBase -> PlayerArray (TArray<APlayerState*>)
    u32 PawnPrivate        = 0x2A8;  // APlayerState -> PawnPrivate
    u32 TeamOffset         = 0x3F0;  // PlayerState -> team index byte (0 = disable check)

    u32 Mesh               = 0x308;  // ACharacter -> Mesh (USkeletalMeshComponent*)
    u32 ComponentToWorld   = 0x1F0;  // USceneComponent -> ComponentToWorld (FTransform)
    u32 BoneArray          = 0x240;  // USkinnedMeshComponent -> ComponentSpaceTransformsArray (TArray ptr)
    u32 BoneCount          = 0x248;  // -> TArray.Num()
    u32 LastRenderTime     = 0x2E8;  // UPrimitiveComponent -> LastRenderTime (float)

    u32 ControlRotation    = 0x2A0;  // AController -> ControlRotation (FRotator)
    u32 Weapon             = 0x9A0;  // Pawn -> CurrentWeapon (object*)
    u32 ObjectName         = 0x18;   // UObject -> NamePrivate (FName index)
    u32 Health             = 0x0;    // pawn health float; 0 = disabled

    // class reflection walk (touch-drive: find AddYawInput/AddPitchInput UFunctions)
    u32 ClassPrivate       = 0x10;   // UObject -> ClassPrivate
    u32 SuperStruct        = 0x40;   // UStruct -> SuperStruct
    u32 Children           = 0x48;   // UStruct -> Children (FField chain)
    u32 FieldNext          = 0x20;   // FField -> Next
    u32 FieldName          = 0x18;   // FField -> NamePrivate (FName index)
    u32 PEVtableIndex      = 0x42;   // UObject::ProcessEvent vtable index

    // FNamePool decoding
    u32 NameStride         = 2;      // FNameEntry stride inside block
    u32 NameLenShift       = 6;      // header >> shift = len
    u32 NameXorKey         = 0;      // optional per-char XOR (Tencent builds), 0 = plain
};

extern Offsets OFF;

inline bool fine(f32 v) { return std::isfinite(v); }
